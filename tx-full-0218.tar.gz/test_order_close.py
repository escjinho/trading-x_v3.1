#!/usr/bin/env python3
"""
MetaAPI 주문/청산 테스트 스크립트
BTCUSD 0.01 lot BUY → 5초 대기 → 청산
"""

import asyncio
import httpx
import time

BASE_URL = "http://localhost:8000/api/mt5"

# 테스트용 토큰 (실제 유저 토큰으로 교체 필요)
# 토큰 없이 테스트하려면 curl로 직접 테스트
TEST_TOKEN = None


async def test_order_and_close():
    print("=" * 60)
    print("MetaAPI 주문/청산 테스트")
    print("=" * 60)

    async with httpx.AsyncClient(timeout=30.0) as client:
        headers = {}
        if TEST_TOKEN:
            headers["Authorization"] = f"Bearer {TEST_TOKEN}"

        # 1. 주문 실행
        print("\n[1] BTCUSD 0.01 lot BUY 주문...")
        try:
            response = await client.post(
                f"{BASE_URL}/order",
                params={
                    "symbol": "BTCUSD",
                    "order_type": "BUY",
                    "volume": 0.01,
                    "target": 0,  # TP/SL 없음
                    "magic": 100001
                },
                headers=headers
            )
            order_result = response.json()
            print(f"    응답: {order_result}")

            if not order_result.get("success"):
                print("    ❌ 주문 실패!")
                return

            position_id = order_result.get("positionId")
            print(f"    ✅ 주문 성공! positionId: {position_id}")

        except Exception as e:
            print(f"    ❌ 주문 오류: {e}")
            return

        # 2. 5초 대기
        print("\n[2] 5초 대기 중...")
        for i in range(5, 0, -1):
            print(f"    {i}초...")
            await asyncio.sleep(1)

        # 3. 포지션 조회
        print("\n[3] 포지션 조회...")
        try:
            response = await client.get(
                f"{BASE_URL}/positions",
                headers=headers
            )
            positions_result = response.json()
            print(f"    포지션 수: {positions_result.get('count', 0)}")
            if positions_result.get('positions'):
                for pos in positions_result['positions']:
                    print(f"    - {pos.get('symbol')} {pos.get('type')} {pos.get('volume')} lot, P/L: ${pos.get('profit', 0):.2f}")
        except Exception as e:
            print(f"    포지션 조회 오류: {e}")

        # 4. 청산
        print("\n[4] 청산 실행...")
        try:
            close_params = {
                "symbol": "BTCUSD",
                "magic": 100001
            }
            if position_id:
                close_params["position_id"] = position_id

            response = await client.post(
                f"{BASE_URL}/close",
                params=close_params,
                headers=headers
            )
            close_result = response.json()
            print(f"    응답: {close_result}")

            if close_result.get("success"):
                profit = close_result.get("profit", 0)
                print(f"    ✅ 청산 성공! P/L: ${profit:.2f}")
            else:
                print(f"    ❌ 청산 실패: {close_result.get('message')}")

        except Exception as e:
            print(f"    ❌ 청산 오류: {e}")

    print("\n" + "=" * 60)
    print("테스트 완료")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(test_order_and_close())
