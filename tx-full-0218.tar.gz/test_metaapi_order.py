#!/usr/bin/env python3
"""
MetaAPI 주문/청산 직접 테스트 스크립트
BTCUSD 0.01 lot BUY → 5초 대기 → 청산
"""

import asyncio
import sys
import os

# 프로젝트 경로 추가
sys.path.insert(0, '/var/www/trading-x/backend')
os.chdir('/var/www/trading-x/backend')

from app.api.metaapi_service import metaapi_service


async def test_order_and_close():
    print("=" * 60)
    print("MetaAPI 주문/청산 직접 테스트")
    print("Trade Account: ab8b3c02-5390-4d9a-b879-8b8c86f1ebf5")
    print("=" * 60)

    # 1. Trade 계정 연결
    print("\n[1] Trade 계정 연결 중...")
    connected = await metaapi_service.connect_trade_account()
    if not connected:
        print("    ❌ Trade 계정 연결 실패!")
        return
    print("    ✅ Trade 계정 연결 성공!")

    # 2. 현재 포지션 확인
    print("\n[2] 현재 포지션 조회...")
    positions_before = await metaapi_service.get_positions()
    print(f"    현재 포지션 수: {len(positions_before)}")
    for pos in positions_before:
        print(f"    - {pos.get('symbol')} {pos.get('type')} {pos.get('volume')} lot")

    # 3. BUY 주문
    print("\n[3] BTCUSD 0.01 lot BUY 주문...")
    order_result = await metaapi_service.place_order(
        symbol="BTCUSD",
        order_type="BUY",
        volume=0.01,
        magic=100001,
        comment="Test Order"
    )
    print(f"    결과: {order_result}")

    if not order_result.get('success'):
        print(f"    ❌ 주문 실패: {order_result.get('error')}")
        return

    position_id = order_result.get('positionId')
    print(f"    ✅ 주문 성공! positionId: {position_id}")

    # 4. 5초 대기
    print("\n[4] 5초 대기 중...")
    for i in range(5, 0, -1):
        print(f"    {i}초...")
        await asyncio.sleep(1)

    # 5. 포지션 확인
    print("\n[5] 포지션 확인...")
    positions_after = await metaapi_service.get_positions()
    print(f"    현재 포지션 수: {len(positions_after)}")
    target_position = None
    for pos in positions_after:
        profit = pos.get('profit', 0)
        print(f"    - {pos.get('symbol')} {pos.get('type')} {pos.get('volume')} lot, P/L: ${profit:.2f}")
        if pos.get('id') == position_id or (pos.get('symbol') == 'BTCUSD' and pos.get('magic') == 100001):
            target_position = pos

    # 6. 청산
    print("\n[6] 청산 실행...")
    if position_id:
        close_result = await metaapi_service.close_position(position_id)
    elif target_position:
        close_result = await metaapi_service.close_position(target_position.get('id'))
    else:
        print("    ❌ 청산할 포지션을 찾을 수 없음")
        return

    print(f"    결과: {close_result}")

    if close_result.get('success'):
        print(f"    ✅ 청산 성공!")
    else:
        print(f"    ❌ 청산 실패: {close_result.get('error')}")

    # 7. 최종 포지션 확인
    print("\n[7] 최종 포지션 확인...")
    positions_final = await metaapi_service.get_positions()
    print(f"    최종 포지션 수: {len(positions_final)}")

    print("\n" + "=" * 60)
    print("테스트 완료")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(test_order_and_close())
