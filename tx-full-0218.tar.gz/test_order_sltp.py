#!/usr/bin/env python3
"""
MetaAPI SL/TP 주문 테스트
BTCUSD 0.01 lot BUY, target=$50 → SL/TP 자동 설정
"""

import asyncio
import sys
sys.path.insert(0, '/var/www/trading-x/backend')

from app.api.metaapi_service import metaapi_service, quote_price_cache

async def test_order_with_sltp():
    print("=" * 60)
    print("MetaAPI SL/TP 주문 테스트")
    print("=" * 60)

    # 1. Trade 계정 연결
    print("\n[1] Trade 계정 연결 중...")
    connected = await metaapi_service.connect_trade_account()
    if not connected:
        print("    ❌ Trade 계정 연결 실패!")
        return
    print("    ✅ Trade 계정 연결 성공!")

    # 2. 현재가 확인
    print("\n[2] 현재가 확인...")
    symbol = "BTCUSD"
    price_data = quote_price_cache.get(symbol, {})
    bid = price_data.get('bid', 0)
    ask = price_data.get('ask', 0)
    print(f"    {symbol}: bid={bid}, ask={ask}")

    if bid == 0 or ask == 0:
        print("    ❌ 현재가 없음. 시세 조회 필요.")
        # 직접 시세 조회
        await metaapi_service.get_prices([symbol])
        await asyncio.sleep(1)
        price_data = quote_price_cache.get(symbol, {})
        bid = price_data.get('bid', 0)
        ask = price_data.get('ask', 0)
        print(f"    재조회: bid={bid}, ask={ask}")

    # 3. SL/TP 계산 (target=$50 기준)
    target = 50  # 목표 수익 $50
    volume = 0.01
    tick_value = 0.01  # BTCUSD tick_value
    tick_size = 0.01   # BTCUSD tick_size (point)

    tp_points = int(target / (volume * tick_value))
    sl_points = tp_points

    print(f"\n[3] SL/TP 계산...")
    print(f"    target=${target}, volume={volume}")
    print(f"    tp_points={tp_points}, sl_points={sl_points}")

    # BUY 주문 기준
    expected_tp = round(ask + (tp_points * tick_size), 5)
    expected_sl = round(ask - (sl_points * tick_size), 5)
    print(f"    예상 TP: {expected_tp}")
    print(f"    예상 SL: {expected_sl}")

    # 4. 주문 실행
    print("\n[4] BTCUSD 0.01 lot BUY 주문 (target=$50)...")
    result = await metaapi_service.place_order(
        symbol=symbol,
        order_type="BUY",
        volume=volume,
        sl_points=sl_points,
        tp_points=tp_points,
        magic=100001,
        comment="SL/TP Test"
    )
    print(f"    결과: {result}")

    if not result.get('success'):
        print(f"    ❌ 주문 실패: {result.get('error')}")
        return

    position_id = result.get('positionId')
    print(f"    ✅ 주문 성공! positionId: {position_id}")

    # 5. 포지션 확인
    print("\n[5] 포지션 확인 (3초 대기)...")
    await asyncio.sleep(3)
    positions = await metaapi_service.get_positions()
    print(f"    포지션 수: {len(positions)}")

    for pos in positions:
        if pos.get('id') == position_id or pos.get('magic') == 100001:
            print(f"    - Symbol: {pos.get('symbol')}")
            print(f"    - Type: {pos.get('type')}")
            print(f"    - Volume: {pos.get('volume')}")
            print(f"    - Entry: {pos.get('openPrice')}")
            print(f"    - StopLoss: {pos.get('stopLoss')}")
            print(f"    - TakeProfit: {pos.get('takeProfit')}")
            print(f"    - Profit: {pos.get('profit')}")

    # 6. 청산
    print("\n[6] 청산 실행 (5초 후)...")
    await asyncio.sleep(5)
    close_result = await metaapi_service.close_position(position_id)
    print(f"    청산 결과: {close_result}")

    print("\n" + "=" * 60)
    print("테스트 완료")
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(test_order_with_sltp())
