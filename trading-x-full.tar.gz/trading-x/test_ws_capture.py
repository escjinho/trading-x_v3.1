#!/usr/bin/env python3
"""
WebSocket 캡처 스크립트 - MetaAPI 캐시 데이터 확인
10초간 WS 메시지를 수신하여 balance, positions 확인
"""

import asyncio
import websockets
import json

WS_URL = "ws://localhost:8000/api/mt5/ws"

async def capture_ws():
    print("=" * 60)
    print("WebSocket 캡처 시작 (10초)")
    print("=" * 60)

    try:
        async with websockets.connect(WS_URL) as ws:
            print(f"연결됨: {WS_URL}\n")

            start_time = asyncio.get_event_loop().time()
            msg_count = 0

            while (asyncio.get_event_loop().time() - start_time) < 10:
                try:
                    msg = await asyncio.wait_for(ws.recv(), timeout=2.0)
                    data = json.loads(msg)
                    msg_count += 1

                    print(f"[메시지 #{msg_count}]")

                    # 계정 정보 (최상위 레벨)
                    print(f"  계정 정보:")
                    print(f"    - mt5_connected: {data.get('mt5_connected')}")
                    print(f"    - balance: {data.get('balance')}")
                    print(f"    - equity: {data.get('equity')}")
                    print(f"    - margin: {data.get('margin')}")
                    print(f"    - free_margin: {data.get('free_margin')}")
                    print(f"    - positions_count: {data.get('positions_count')}")

                    # 포지션 확인
                    if data.get('position'):
                        pos = data['position']
                        print(f"  position:")
                        print(f"    * {pos.get('symbol')} {pos.get('type')} {pos.get('volume')} lot")
                        print(f"      entry: {pos.get('entry')}, profit: {pos.get('profit')}")

                    # sync_event 확인
                    sync = data.get("sync_event")
                    if sync:
                        print(f"  sync_event: {sync}")

                    # price 확인
                    if "all_prices" in data:
                        prices = data["all_prices"]
                        btc = prices.get("BTCUSD", {})
                        if btc:
                            print(f"  BTCUSD: bid={btc.get('bid')}, ask={btc.get('ask')}")

                    # indicators 확인
                    buy = data.get("buy_count", 0) or 0
                    sell = data.get("sell_count", 0) or 0
                    neutral = data.get("neutral_count", 0) or 0
                    print(f"  indicators: buy={buy}, sell={sell}, neutral={neutral}")
                    total = buy + sell + neutral
                    print(f"    sum: {total}")

                    print()

                except asyncio.TimeoutError:
                    print("  (대기 중...)")
                    continue

            print("=" * 60)
            print(f"캡처 완료: 총 {msg_count}개 메시지 수신")
            print("=" * 60)

    except Exception as e:
        print(f"오류: {e}")

if __name__ == "__main__":
    asyncio.run(capture_ws())
