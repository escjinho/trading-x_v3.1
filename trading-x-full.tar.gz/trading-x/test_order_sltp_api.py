#!/usr/bin/env python3
"""
API를 통한 SL/TP 주문 테스트
BTCUSD 0.01 lot BUY, target=$50
"""

import asyncio
import httpx

BASE_URL = "http://localhost:8000/api"

async def test():
    print("=" * 60)
    print("SL/TP 주문 API 테스트")
    print("=" * 60)

    async with httpx.AsyncClient(timeout=30.0) as client:
        # 1. 로그인
        print("\n[1] 로그인...")
        login_resp = await client.post(
            f"{BASE_URL}/auth/login",
            json={"email": "test_api@test.com", "password": "test123"}
        )
        if login_resp.status_code != 200:
            print(f"    ❌ 로그인 실패: {login_resp.status_code}")
            return
        token = login_resp.json().get("access_token")
        headers = {"Authorization": f"Bearer {token}"}
        print("    ✅ 로그인 성공")

        # 2. 현재 포지션 확인
        print("\n[2] 현재 포지션 확인...")
        pos_resp = await client.get(f"{BASE_URL}/mt5/positions", headers=headers)
        pos_data = pos_resp.json()
        print(f"    포지션 수: {pos_data.get('count', 0)}")

        # 3. BUY 주문 (target=50)
        print("\n[3] BTCUSD 0.01 lot BUY 주문 (target=$50)...")
        order_resp = await client.post(
            f"{BASE_URL}/mt5/order",
            params={
                "symbol": "BTCUSD",
                "order_type": "BUY",
                "volume": 0.01,
                "target": 50,  # ★ SL/TP 목표 수익
                "magic": 100001
            },
            headers=headers
        )
        order_data = order_resp.json()
        print(f"    응답: {order_data}")

        if not order_data.get("success"):
            print(f"    ❌ 주문 실패: {order_data.get('message')}")
            return

        position_id = order_data.get("positionId")
        print(f"    ✅ 주문 성공! positionId: {position_id}")

        # 4. 포지션 확인 (3초 대기)
        print("\n[4] 포지션 SL/TP 확인 (3초 대기)...")
        await asyncio.sleep(3)
        pos_resp = await client.get(f"{BASE_URL}/mt5/positions", headers=headers)
        pos_data = pos_resp.json()
        print(f"    포지션 수: {pos_data.get('count', 0)}")

        for pos in pos_data.get('positions', []):
            print(f"\n    ▶ 포지션 상세:")
            print(f"      Symbol: {pos.get('symbol')}")
            print(f"      Type: {pos.get('type')}")
            print(f"      Volume: {pos.get('volume')}")
            print(f"      Entry: {pos.get('entry')}")
            print(f"      StopLoss: {pos.get('sl')}")
            print(f"      TakeProfit: {pos.get('tp')}")
            print(f"      Profit: {pos.get('profit')}")

        # 5. 청산 (5초 후)
        print("\n[5] 청산 (5초 후)...")
        await asyncio.sleep(5)
        close_resp = await client.post(
            f"{BASE_URL}/mt5/close",
            params={
                "symbol": "BTCUSD",
                "magic": 100001,
                "position_id": position_id
            },
            headers=headers
        )
        close_data = close_resp.json()
        print(f"    청산 결과: {close_data}")

    print("\n" + "=" * 60)
    print("테스트 완료")
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(test())
