/* ========================================
   Chart Panel Module
   TradingView Lightweight Charts 렌더링 및 관리
   ======================================== */

const ChartPanel = {
    // 마지막 캔들 데이터 저장
    lastCandleTime: 0,
    lastCandleData: null,

    // ★ 부드러운 가격 보간을 위한 속성
    _animTarget: null,
    _animCurrent: null,
    _animFrameId: null,
    _bidTarget: null,
    _bidCurrent: null,
    _bidAnimFrameId: null,

    // ★ 자동 복귀 시스템 속성
    _autoReturnTimer: null,
    _autoReturnDelay: 5000,  // 5초 비활동 후 자동 복귀
    _isAutoReturning: false,  // ★ 자동복귀 중 플래그 (무한루프 방지)
    _isLoadingCandles: false,

    /**
     * 차트 패널 초기화
     */
    init() {
        console.log('[ChartPanel] ★★★ init() 시작 ★★★');
        this.initChart();
        this.setupTimeframeButtons();
        this.lastCandleTime = 0;
        this.lastCandleData = null;
        setTimeout(() => this.loadCandles(), 500);  // ★ 초기 차트 캔들 로딩 (WS보다 늦게)
        console.log('[ChartPanel] Initialized');
    },

    /**
     * 안전한 캔들 업데이트 (모든 타임프레임 지원)
     * 현재 캔들의 close 가격을 실시간으로 업데이트하고, high/low도 조정
     * ★ 부드러운 보간 적용
     */
    safeUpdateCandle(candleData) {
        if (!candleData || !chart || !candleSeries || !candleData.close) {
            return false;
        }

        // ★ 장 마감 시 차트 업데이트 중단 (isCurrentMarketClosed — MT5 크로스 체크 포함)
        if (typeof isCurrentMarketClosed === 'function' && isCurrentMarketClosed(chartSymbol)) {
            return false;
        }

        // time이 없으면 lastCandleTime 사용 (WS에서 {close: bid}만 전달하는 경우)
        if (!candleData.time && this.lastCandleTime > 0) {
            candleData.time = this.lastCandleTime;
        } else if (candleData.time) {
            // ★ KST 변환 (+9시간) — 차트 표시용 (중복 변환 방지)
            const KST_OFFSET = 9 * 3600;
            if (this.lastCandleTime > 0 && this.lastCandleTime - candleData.time > KST_OFFSET - 3600) {
                candleData.time += KST_OFFSET;
            }
        }
        if (!candleData.time) return false;

        // ★ 타임프레임별 새 캔들 감지 (all_candles의 time으로 판단)
        if (candleData.time && this.lastCandleTime > 0) {
            const _tfSec = {M1:60,M5:300,M15:900,M30:1800,H1:3600,H4:14400};
            const _sec = _tfSec[typeof currentTimeframe !== 'undefined' ? currentTimeframe : 'M1'];
            if (_sec) {
                const _expected = Math.floor(candleData.time / _sec) * _sec;
                if (_expected > this.lastCandleTime) {
                    this.lastCandleTime = _expected;
                    const _price = candleData.close;
                    this.lastCandleData = { time: _expected, open: _price, high: _price, low: _price, close: _price };
                    this._animCurrent = _price;
                    this._animTarget = _price;
                    try {
                        if (typeof ChartTypeManager !== 'undefined') {
                            ChartTypeManager.updateLastCandle(this.lastCandleData);
                        } else {
                            candleSeries.update(this.lastCandleData);
                        }
                    } catch(e) {}
                    return true;
                }
            }
        }

        try {
            const newClose = candleData.close;

            // ★ lastCandleData가 없으면 WebSocket 데이터로 초기화
            if (!this.lastCandleData || this.lastCandleTime === 0) {
                if (candleData.time && candleData.open) {
                    this.lastCandleTime = candleData.time;
                    this.lastCandleData = {
                        time: candleData.time,
                        open: candleData.open,
                        high: candleData.high || candleData.open,
                        low: candleData.low || candleData.open,
                        close: newClose || candleData.open
                    };
                    this._animCurrent = newClose;
                    this._animTarget = newClose;
                    console.log('[ChartPanel] lastCandleData initialized from WebSocket');
                }
                return false;
            }

            // ★ high/low는 즉시 반영
            this.lastCandleData.high = Math.max(this.lastCandleData.high, newClose);
            this.lastCandleData.low = Math.min(this.lastCandleData.low, newClose);

            // ★ close는 부드럽게 보간
            this._animTarget = newClose;
            if (this._animCurrent === null) {
                this._animCurrent = newClose;
            }

            // 애니메이션 시작
            if (!this._animFrameId) {
                this._animatePrice();
            }

            return true;
        } catch (e) {
            console.warn('[ChartPanel] Candle update skipped:', e.message);
        }
        return false;
    },

    /**
     * ★ 부드러운 가격 보간 애니메이션
     */
    _animatePrice() {
        if (this._animCurrent === null || this._animTarget === null) {
            this._animFrameId = null;
            return;
        }

        const diff = this._animTarget - this._animCurrent;
        const decimals = typeof getDecimalsForSymbol === 'function' ? getDecimalsForSymbol(chartSymbol) : 2;
        const threshold = Math.pow(10, -decimals);

        // 차이가 작으면 타겟으로 확정
        if (Math.abs(diff) < threshold) {
            this._animCurrent = this._animTarget;
        } else {
            // 부드럽게 이동 (30% 씩 접근)
            this._animCurrent += diff * 0.3;
        }

        // 캔들 업데이트 (★ try-catch로 "Value is null" 에러 방어)
        if (this.lastCandleData && candleSeries && this.lastCandleTime) {
            this.lastCandleData.close = this._animCurrent;
            const updatedCandle = {
                time: this.lastCandleTime,
                open: this.lastCandleData.open,
                high: this.lastCandleData.high,
                low: this.lastCandleData.low,
                close: this._animCurrent
            };

            try {
                if (typeof ChartTypeManager !== 'undefined') {
                    ChartTypeManager.updateLastCandle(updatedCandle);
                } else {
                    candleSeries.update(updatedCandle);
                }
            } catch (e) {
                // lightweight-charts "Value is null" 무시
            }
        }

        // 타겟에 도달하지 않았으면 계속 애니메이션
        if (Math.abs(this._animTarget - this._animCurrent) >= threshold) {
            this._animFrameId = requestAnimationFrame(() => this._animatePrice());
        } else {
            this._animFrameId = null;
        }
    },

    /**
     * 타임프레임 표시 형식 변환 (API → UI)
     */
    getTimeframeDisplay(tf) {
        const displayMap = {
            'M1': '1m', 'M5': '5m', 'M15': '15m', 'M30': '30m',
            'H1': '1H', 'H4': '4H', 'D1': '1D', 'W1': '1W', 'MN1': 'MN'
        };
        return displayMap[tf] || tf;
    },

    /**
     * TradingView Lightweight Chart 초기화
     */
    initChart() {
        const container = document.getElementById('chart-container');
        if (!container) {
            console.warn('[ChartPanel] Chart container not found');
            return;
        }

    // ★ 가용 높이 동적 계산 (fixed 요소는 상수 사용)
    const containerWidth = container.clientWidth || 800;
    const _hdr = document.querySelector('.header');
    const _sym = document.querySelector('.chart-symbol-row');
    const _headerH = _hdr ? _hdr.offsetHeight : 45;
    const _symbolH = _sym ? _sym.offsetHeight : 40;
    const _fixedBottom = 127; // 네비바(52) + 버튼바(48) — position:fixed라 상수 처리
    const containerHeight = Math.max(window.innerHeight - _headerH - _symbolH - _fixedBottom, 300);
    // wrapper 높이만 설정 (container는 CSS flex:1이 자동 결정)
    const _wrapper = document.getElementById('chart-wrapper');
    if (_wrapper) { _wrapper.style.height = containerHeight + 'px'; }
    console.log('[ChartPanel] Dynamic height:', containerHeight, '(vh:', window.innerHeight, 'hdr:', _headerH, 'sym:', _symbolH, 'fixedBottom:', _fixedBottom, ')');

        const decimals = typeof getDecimalsForSymbol === 'function' ? getDecimalsForSymbol(chartSymbol) : 2;

        chart = LightweightCharts.createChart(container, {
            width: containerWidth,
            height: containerHeight, // 모바일: 500px, PC: 720px
            layout: {
                background: { color: '#000000' },
                textColor: '#b0b0b0'  // 더 밝은 회색
            },
            grid: {
                vertLines: { visible: false },
                horzLines: { visible: false }
            },
            crosshair: {
                mode: LightweightCharts.CrosshairMode.Normal
            },
            rightPriceScale: {
                borderColor: 'rgba(255,255,255,0.2)',
                borderVisible: false,  // Y축 경계선 제거
                autoScale: true,
                visible: true,
                scaleMargins: { top: 0.1, bottom: 0.15 },
            },
            timeScale: {
                borderColor: 'rgba(255,255,255,0.4)',
                borderVisible: false,    // CSS로 연장 구분선 처리 (#chart-wrapper::after)
                timeVisible: true,
                rightOffset: 12,
                shiftVisibleRangeOnNewBar: true,
                fixRightEdge: false,
                fixLeftEdge: false
            },
            localization: {
                priceFormatter: (price) => price.toFixed(getDecimalsForSymbol(chartSymbol)),
            },
        });

        // ChartTypeManager 초기화 및 시리즈 생성
        if (typeof ChartTypeManager !== 'undefined') {
            ChartTypeManager.init(chart);
            // 차트 스타일 오버라이드 (제로마켓 색상)
            ChartTypeManager.styles.candlestick = {
                upColor: '#00b894',
                downColor: '#dc3545',
                borderUpColor: '#00b894',
                borderDownColor: '#dc3545',
                wickUpColor: '#00b894',
                wickDownColor: '#dc3545',
                priceFormat: {
                    type: 'price',
                    precision: decimals,
                    minMove: decimals === 5 ? 0.00001 : decimals === 3 ? 0.001 : 0.01,
                }
            };
            ChartTypeManager.styles.hollowCandle = {
                upColor: 'transparent',
                downColor: 'transparent',
                borderUpColor: '#00b894',
                borderDownColor: '#dc3545',
                wickUpColor: '#00b894',
                wickDownColor: '#dc3545',
                priceFormat: {
                    type: 'price',
                    precision: decimals,
                    minMove: decimals === 5 ? 0.00001 : decimals === 3 ? 0.001 : 0.01,
                }
            };
            ChartTypeManager.styles.line.priceFormat = {
                type: 'price',
                precision: decimals,
                minMove: decimals === 5 ? 0.00001 : decimals === 3 ? 0.001 : 0.01,
            };
            ChartTypeManager.styles.bar = {
                upColor: '#00b894',
                downColor: '#dc3545',
                openVisible: true,
                thinBars: false,
                priceFormat: {
                    type: 'price',
                    precision: decimals,
                    minMove: decimals === 5 ? 0.00001 : decimals === 3 ? 0.001 : 0.01,
                }
            };
            candleSeries = ChartTypeManager.createSeries();
            // createSeries에서 window.candleSeries 동기화됨
            console.log('[ChartPanel] initChart: candleSeries=', candleSeries ? 'OK' : 'NULL', 'ChartTypeManager.series=', ChartTypeManager.series ? 'OK' : 'NULL');
        } else {
            // ChartTypeManager 없으면 기본 캔들스틱
            candleSeries = chart.addCandlestickSeries({
                upColor: '#00b894',
                downColor: '#dc3545',
                borderUpColor: '#00b894',
                borderDownColor: '#dc3545',
                wickUpColor: '#00b894',
                wickDownColor: '#dc3545',
                priceFormat: {
                    type: 'price',
                    precision: decimals,
                    minMove: decimals === 5 ? 0.00001 : decimals === 3 ? 0.001 : 0.01,
                },
            });
            // ★★★ window 동기화 ★★★
            window.candleSeries = candleSeries;
        }
        // ★★★ chart도 window에 동기화 ★★★
        window.chart = chart;

        // 볼린저 밴드 및 LWMA 지표 (기본값 숨김)
        bbUpperSeries = chart.addLineSeries({
            color: '#00bfff',
            lineWidth: 1,
            priceLineVisible: false,
            lastValueVisible: false,
            visible: false
        });
        bbMiddleSeries = chart.addLineSeries({
            color: '#00bfff',
            lineWidth: 1,
            lineStyle: 2,
            priceLineVisible: false,
            lastValueVisible: false,
            visible: false
        });
        bbLowerSeries = chart.addLineSeries({
            color: '#00bfff',
            lineWidth: 1,
            priceLineVisible: false,
            lastValueVisible: false,
            visible: false
        });
        lwmaSeries = chart.addLineSeries({
            color: '#ffff00',
            lineWidth: 2,
            priceLineVisible: false,
            lastValueVisible: false,
            visible: false
        });

        // 반응형 리사이즈 (★ 중복 방지: 기존 핸들러 제거 후 추가)
        if (this._resizeHandler) {
            window.removeEventListener('resize', this._resizeHandler);
        }
        this._resizeHandler = () => {
            if (!chart) return;
            // 가용 높이 재계산
            const _hdr = document.querySelector('.header');
            const _sym = document.querySelector('.chart-symbol-row');
            const _headerH = _hdr ? _hdr.offsetHeight : 45;
            const _symbolH = _sym ? _sym.offsetHeight : 40;
            const _fixedBottom = 127;
            const newH = Math.max(window.innerHeight - _headerH - _symbolH - _fixedBottom, 300);
            const wr = document.getElementById('chart-wrapper');
            if (wr) { wr.style.height = newH + 'px'; }
            // 보조지표가 있으면 IndicatorManager에게 레이아웃 위임
            if (typeof IndicatorManager !== 'undefined' && IndicatorManager.updateLayout && typeof IndicatorConfig !== 'undefined' && IndicatorConfig.getEnabledPanelCount() > 0) {
                IndicatorManager.updateLayout();
            } else {
                // 보조지표 없으면 container가 전체 높이 사용 (CSS flex:1이 높이 결정)
                chart.resize(container.clientWidth, newH);
            }
        };
        window.addEventListener('resize', this._resizeHandler);

        // IndicatorManager 초기화
        if (typeof IndicatorManager !== 'undefined') {
            IndicatorManager.init(chart, candleSeries);
            console.log('[ChartPanel] IndicatorManager initialized');
        }
    },

    /**
     * 캔들 데이터 로드
     */
    async loadCandles() {
        console.log('[ChartPanel.loadCandles] ★★★ 함수 진입 ★★★');
        // ★ 보간 상태 + 캔들 상태 초기화 (종목/타임프레임 변경 시 늘어남+번쩍임 방지)
        this._animTarget = null;
        this._animCurrent = null;
        this._bidTarget = null;
        this._bidCurrent = null;
        this.lastCandleTime = 0;
        this.lastCandleData = null;
        if (this._animFrameId) cancelAnimationFrame(this._animFrameId);
        if (this._bidAnimFrameId) cancelAnimationFrame(this._bidAnimFrameId);
        this._animFrameId = null;
        this._bidAnimFrameId = null;

        try {
            console.log(`[ChartPanel.loadCandles] 요청 시작: ${chartSymbol} ${currentTimeframe}`);
            const data = await apiCall(`/mt5/candles/${chartSymbol}?timeframe=${currentTimeframe}&count=1000`);
            console.log(`[ChartPanel.loadCandles] ${chartSymbol} ${currentTimeframe} → ${data?.candles?.length || 0}개 캔들`, data?.error || '');

            if (data && data.candles && data.candles.length > 0) {
                // ★ chart/series가 없으면 재생성
                if (typeof ChartTypeManager !== 'undefined' && (!ChartTypeManager.chart || !ChartTypeManager.series)) {
                    console.warn('[ChartPanel] Chart/series null — reinitializing');
                    this.initChart();
                }

                // ★ KST 변환 (+9시간) — 차트 표시용
                const KST_OFFSET = 9 * 3600;
                data.candles.forEach(c => { c.time += KST_OFFSET; });
                if (data.indicators) {
                    ['bb_upper', 'bb_middle', 'bb_lower', 'lwma'].forEach(key => {
                        if (data.indicators[key]) {
                            data.indicators[key].forEach(d => { d.time += KST_OFFSET; });
                        }
                    });
                }

                // ChartTypeManager를 통해 데이터 설정
                if (typeof ChartTypeManager !== 'undefined') {
                    ChartTypeManager.setData(data.candles);
                    candleSeries = ChartTypeManager.series;
                } else if (candleSeries) {
                    candleSeries.setData(data.candles);
                }

                // 마지막 캔들 데이터 저장 (실시간 업데이트용)
                const lastCandle = data.candles[data.candles.length - 1];
                this.lastCandleTime = lastCandle.time;
                this.lastCandleData = { ...lastCandle };

                // 기준가격 설정 (★ D1 시가 우선, fallback: 첫 캔들 시가)
                if (window._dailyOpen && window._dailyOpen[chartSymbol]) {
                    this.referencePrice = window._dailyOpen[chartSymbol];
                } else {
                    this.referencePrice = data.candles[0].open;
                    // D1 시가 비동기 로딩
                    apiCall('/mt5/candles/' + chartSymbol + '?timeframe=D1&count=1').then(d1 => {
                        if (d1 && d1.candles && d1.candles.length > 0) {
                            this.referencePrice = d1.candles[d1.candles.length - 1].open;
                            window._dailyOpen = window._dailyOpen || {};
                            window._dailyOpen[chartSymbol] = this.referencePrice;
                            console.log('[ChartPanel] ★ D1 시가:', this.referencePrice);
                        }
                    }).catch(() => {});
                }

                // 인디케이터 데이터 설정 (★ null 체크 + try-catch)
                if (data.indicators) {
                    try {
                        if (data.indicators.bb_upper && bbUpperSeries) bbUpperSeries.setData(data.indicators.bb_upper);
                        if (data.indicators.bb_middle && bbMiddleSeries) bbMiddleSeries.setData(data.indicators.bb_middle);
                        if (data.indicators.bb_lower && bbLowerSeries) bbLowerSeries.setData(data.indicators.bb_lower);
                        if (data.indicators.lwma && lwmaSeries) lwmaSeries.setData(data.indicators.lwma);
                    } catch (e) {
                        // lightweight-charts "Value is null" 무시
                    }

                    // ★★★ BB/LWMA 가시성 제어 — localStorage 상태 기반 복원 ★★★
                    if (typeof this._indicatorsInitialized === 'undefined' || !this._indicatorsInitialized) {
                        const _bbOn = (typeof IndicatorConfig !== 'undefined' && IndicatorConfig.overlay.bb) ? IndicatorConfig.overlay.bb.enabled : false;
                        const _lwmaOn = (typeof IndicatorConfig !== 'undefined' && IndicatorConfig.overlay.lwma) ? IndicatorConfig.overlay.lwma.enabled : false;
                        if (bbUpperSeries) bbUpperSeries.applyOptions({ visible: _bbOn });
                        if (bbMiddleSeries) bbMiddleSeries.applyOptions({ visible: _bbOn });
                        if (bbLowerSeries) bbLowerSeries.applyOptions({ visible: _bbOn });
                        if (lwmaSeries) lwmaSeries.applyOptions({ visible: _lwmaOn });
                        this._indicatorsInitialized = true;
                        console.log('[ChartPanel] BB/LWMA visibility restored — BB:', _bbOn, 'LWMA:', _lwmaOn);

                        // ★ BB/LWMA 활성화 상태인데 데이터가 이미 로드된 경우 visible 재적용
                        if (_bbOn && data.indicators.bb_upper) {
                            if (bbUpperSeries) bbUpperSeries.applyOptions({ visible: true });
                            if (bbMiddleSeries) bbMiddleSeries.applyOptions({ visible: true });
                            if (bbLowerSeries) bbLowerSeries.applyOptions({ visible: true });
                        }
                        if (_lwmaOn && data.indicators.lwma) {
                            if (lwmaSeries) lwmaSeries.applyOptions({ visible: true });
                        }
                    }
                }

                // ★★★ 적절한 줌 레벨로 현재가 부근 표시 ★★★
                const visibleBars = this.getVisibleBarsForTimeframe();

                // ★★★ setVisibleLogicalRange 사용 (index 기반 = rightOffset 포함 가능) ★★★
                const totalBars = data.candles.length;
                const rightPadding = 6;  // 오른쪽 여백 (빈 봉 수)

                if (totalBars > visibleBars) {
                    // 캔들 충분: 마지막 N개 + 오른쪽 여백
                    try {
                        chart.timeScale().setVisibleLogicalRange({
                            from: totalBars - visibleBars,
                            to: totalBars + rightPadding
                        });
                    } catch (e) {
                        try { chart.timeScale().scrollToRealTime(); } catch(e2) {}
                    }
                } else if (totalBars > 0) {
                    // 캔들 부족: 전체 표시 + 오른쪽 여백
                    try {
                        chart.timeScale().setVisibleLogicalRange({
                            from: 0,
                            to: totalBars + rightPadding
                        });
                    } catch (e) {
                        try { chart.timeScale().scrollToRealTime(); } catch(e2) {}
                    }
                }

                // ★ 가격 스케일 자동 맞춤
                try { chart.priceScale('right').applyOptions({ autoScale: true }); } catch(e) {}

                // 마지막 가격 업데이트
                if (data.candles.length > 0) {
                    this.updateChartPrice(data.candles[data.candles.length - 1].close);
                }

                // IndicatorManager에 캔들 데이터 전달
                if (typeof IndicatorManager !== 'undefined') {
                    IndicatorManager.updateCandleData(data.candles);
                }

                // ★ BB/LWMA visible 최종 안전망 (addIndicator의 setTimeout 이후에 실행)
                // addIndicator가 100ms, 300ms, 600ms setTimeout을 사용하므로 그 이후에 재적용
                setTimeout(() => {
                    if (typeof IndicatorConfig !== 'undefined') {
                        const bbOn = IndicatorConfig.overlay.bb ? IndicatorConfig.overlay.bb.enabled : false;
                        const lwmaOn = IndicatorConfig.overlay.lwma ? IndicatorConfig.overlay.lwma.enabled : false;
                        if (bbUpperSeries) bbUpperSeries.applyOptions({ visible: bbOn });
                        if (bbMiddleSeries) bbMiddleSeries.applyOptions({ visible: bbOn });
                        if (bbLowerSeries) bbLowerSeries.applyOptions({ visible: bbOn });
                        if (lwmaSeries) lwmaSeries.applyOptions({ visible: lwmaOn });
                        // BB/LWMA 데이터가 비어있으면 리로드
                        if ((bbOn || lwmaOn) && typeof this.loadIndicatorsOnly === 'function') {
                            this.loadIndicatorsOnly();
                        }
                        if (bbOn || lwmaOn) {
                            console.log('[ChartPanel] BB/LWMA visible 안전망 실행 — BB:', bbOn, 'LWMA:', lwmaOn);
                        }
                    }
                }, 800);

                // ★ 자동복귀 미설정 시 재설정 (초기 로드 완료 후)
                if (!this._chartTouchHandler) {
                    setTimeout(() => this.setupAutoReturn(), 500);
                }
            }
        } catch (e) {
            console.error('[ChartPanel] 캔들 로드 실패:', e);
        }
    },

    // ★ 인디케이터만 갱신 (차트 리셋 없이 - 번쩍임 방지)
    async loadIndicatorsOnly() {
        try {
            const data = await apiCall(`/mt5/candles/${chartSymbol}?timeframe=${currentTimeframe}&count=100`);
            if (data && data.indicators) {
                // ★ KST 변환 (+9시간) — loadCandles와 동일하게 적용
                const KST_OFFSET = 9 * 3600;
                ['bb_upper', 'bb_middle', 'bb_lower', 'lwma'].forEach(key => {
                    if (data.indicators[key]) {
                        data.indicators[key].forEach(d => { d.time += KST_OFFSET; });
                    }
                });

                try {
                    if (data.indicators.bb_upper && bbUpperSeries) bbUpperSeries.setData(data.indicators.bb_upper);
                    if (data.indicators.bb_middle && bbMiddleSeries) bbMiddleSeries.setData(data.indicators.bb_middle);
                    if (data.indicators.bb_lower && bbLowerSeries) bbLowerSeries.setData(data.indicators.bb_lower);
                    if (data.indicators.lwma && lwmaSeries) lwmaSeries.setData(data.indicators.lwma);
                } catch (e) {
                    // lightweight-charts "Value is null" 무시
                }
            }
        } catch (e) {
            console.error('[ChartPanel] 인디케이터 갱신 실패:', e);
        }
    },

    // 기준가격 (첫 번째 캔들의 시가 또는 이전 종가)
    referencePrice: null,

    /**
     * ★ 부드러운 bid/ask 보간 애니메이션
     */
    _animateBid(decimals, spread) {
        if (this._bidCurrent === null || this._bidTarget === null) {
            this._bidAnimFrameId = null;
            return;
        }

        const diff = this._bidTarget - this._bidCurrent;
        const threshold = Math.pow(10, -decimals);

        // 차이가 작으면 타겟으로 확정
        if (Math.abs(diff) < threshold) {
            this._bidCurrent = this._bidTarget;
        } else {
            // 부드럽게 이동 (30% 씩 접근)
            this._bidCurrent += diff * 0.3;
        }

        // bid/ask 표시 업데이트
        const bidEl = document.getElementById('chartBid');
        const askEl = document.getElementById('chartAsk');
        if (bidEl) bidEl.textContent = this.formatWithComma(this._bidCurrent, decimals);
        if (askEl) askEl.textContent = this.formatWithComma(this._bidCurrent + spread, decimals);

        // 타겟에 도달하지 않았으면 계속 애니메이션
        if (Math.abs(this._bidTarget - this._bidCurrent) >= threshold) {
            this._bidAnimFrameId = requestAnimationFrame(() => this._animateBid(decimals, spread));
        } else {
            this._bidAnimFrameId = null;
        }
    },

    /**
     * 숫자에 천 단위 콤마 추가
     */
    formatWithComma(num, decimals) {
        const parts = num.toFixed(decimals).split('.');
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        return parts.join('.');
    },

    /**
     * 차트 가격 업데이트 (제로마켓 스타일)
     * ★ 부드러운 bid/ask 보간 적용
     */
    updateChartPrice(price) {
        const decimals = getDecimalsForSymbol(chartSymbol);
        const spread = chartSymbol === 'BTCUSD' ? 15 :
                      chartSymbol === 'XAUUSD.r' ? 0.50 : 0.00020;

        // ★ bid 보간 타겟 설정
        this._bidTarget = price;
        if (this._bidCurrent === null) {
            this._bidCurrent = price;
        }

        // 애니메이션 시작
        if (!this._bidAnimFrameId) {
            this._animateBid(decimals, spread);
        }

        // 오버레이 요소들
        const overlaySymbol = document.getElementById('overlaySymbol');
        const overlayTimeframe = document.getElementById('overlayTimeframe');
        const overlayCategory = document.getElementById('overlayCategory');
        const overlayMarketStatus = document.getElementById('overlayMarketStatus');
        const overlayPrice = document.getElementById('overlayPrice');
        const overlayChange = document.getElementById('overlayChange');

        // 심볼 정보 가져오기
        const symbolInfo = typeof getSymbolInfo === 'function' ? getSymbolInfo(chartSymbol) : null;

        // 2줄: 심볼, 타임프레임, 카테고리
        if (overlaySymbol) {
            overlaySymbol.textContent = chartSymbol;
        }
        if (overlayTimeframe && typeof currentTimeframe !== 'undefined') {
            // 버튼과 동일한 형식으로 표시 (1m, 5m, 1H 등)
            overlayTimeframe.textContent = this.getTimeframeDisplay(currentTimeframe);
        }
        if (overlayCategory && symbolInfo) {
            overlayCategory.textContent = symbolInfo.category || 'Currency';
        }

        // 장 운영 상태 (★ isCurrentMarketClosed — MT5 크로스 체크 포함)
        if (overlayMarketStatus) {
            const isMarketOpen = typeof isCurrentMarketClosed === 'function'
                ? !isCurrentMarketClosed(chartSymbol)
                : true;
            overlayMarketStatus.classList.toggle('closed', !isMarketOpen);
            const statusText = document.getElementById('overlayMarketStatusText');
            if (statusText) {
                statusText.style.display = isMarketOpen ? 'none' : 'inline';
            }
        }

        // 1줄: 현재가 (천 단위 콤마)
        if (overlayPrice) {
            overlayPrice.textContent = this.formatWithComma(price, decimals);
        }

        // 변동폭/변동률 계산 (천 단위 콤마)
        if (overlayChange && this.referencePrice) {
            const change = price - this.referencePrice;
            const changePercent = (change / this.referencePrice) * 100;
            const isPositive = change >= 0;
            const color = isPositive ? '#00b894' : '#dc3545';
            const sign = isPositive ? '+' : '';

            const changeFormatted = this.formatWithComma(Math.abs(change), decimals);
            overlayChange.textContent = sign + changeFormatted + ' (' + sign + changePercent.toFixed(2) + '%)';
            overlayChange.style.color = color;
        }
    },

    /**
     * 타임프레임 버튼 설정 (기존 호환 + 드롭다운)
    */
    setupTimeframeButtons() {
        // 기존 버튼 방식 호환
        document.querySelectorAll('.tf-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.tf-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                window._isChangingTimeframe = true;
                currentTimeframe = btn.dataset.tf;
                this.loadCandles();
                setTimeout(() => { window._isChangingTimeframe = false; }, 2000);
            });
        });
    
        // 드롭다운 외부 클릭 시 닫기
        document.addEventListener('click', (e) => {
            const container = document.querySelector('.timeframe-dropdown-container');
            const dropdown = document.getElementById('tfDropdown');
            const btn = document.getElementById('tfDropdownBtn');
        
            if (container && !container.contains(e.target)) {
                dropdown?.classList.remove('show');
                btn?.classList.remove('open');
            }
        });
    },

    /**
     * 외부에서 데이터 업데이트
     */
    update(data) {
        // 실시간 캔들 업데이트는 connection.js에서 처리
        // 필요 시 추가 로직 구현
    },

    /**
     * 차트 재초기화
     */
    reinit() {
        if (this._autoReturnTimer) {
            clearTimeout(this._autoReturnTimer);
            this._autoReturnTimer = null;
        }
        this._isAutoReturning = false;
        this._indicatorsInitialized = false;
        // ★ BB/LWMA 시리즈 데이터 초기화 (이전 타임프레임 데이터 잔존 방지)
        try {
            if (bbUpperSeries) bbUpperSeries.setData([]);
            if (bbMiddleSeries) bbMiddleSeries.setData([]);
            if (bbLowerSeries) bbLowerSeries.setData([]);
            if (lwmaSeries) lwmaSeries.setData([]);
        } catch(e) {}
        // ★ IndicatorManager 시리즈만 정리 (enabled 상태는 보존!)
        // removeAll()은 config.enabled를 전부 false로 리셋하므로 사용하지 않음
        if (typeof IndicatorManager !== 'undefined') {
            try {
                // 시각적 시리즈만 제거 (config.enabled는 건드리지 않음)
                Object.keys(IndicatorManager.activeIndicators).forEach(id => {
                    const config = IndicatorConfig.get(id);
                    if (config && config.type === 'overlay') {
                        IndicatorManager.removeOverlayIndicator(id);
                    } else if (config && config.type === 'panel') {
                        IndicatorManager.removePanelIndicator(id);
                    }
                });
                IndicatorManager.activeIndicators = {};

                // 패널 차트 정리
                Object.keys(IndicatorManager.panelCharts).forEach(id => {
                    try { IndicatorManager.panelCharts[id].remove(); } catch(e) {}
                });
                IndicatorManager.panelCharts = {};

                // 패널 DOM 정리
                const panelsEl = document.getElementById('indicator-panels');
                if (panelsEl) panelsEl.innerHTML = '';

                // 메인 차트 높이 복원
                IndicatorManager.restoreMainChartHeight();

                console.log('[reinit] IndicatorManager 시리즈만 정리 (enabled 상태 보존)');
            } catch(e) {
                console.warn('[reinit] IndicatorManager 정리 실패:', e);
            }
        }
        if (chart) {
            chart.remove();
            chart = null;
        }
        this.initChart();
        this.loadCandles();
        // ★ 차트 재생성 후 자동복귀 재설정
        setTimeout(() => this.setupAutoReturn(), 1500);
    },

    /**
 * 보조지표 설정
 */
setIndicators(settings) {
    console.log('[ChartPanel] setIndicators 호출:', JSON.stringify(settings));

    // 볼린저 밴드 표시/숨김 + 데이터 제거
    if (bbUpperSeries) {
        if (settings.bb) {
            bbUpperSeries.applyOptions({ visible: true });
            bbMiddleSeries.applyOptions({ visible: true });
            bbLowerSeries.applyOptions({ visible: true });
        } else {
            bbUpperSeries.setData([]);
            bbMiddleSeries.setData([]);
            bbLowerSeries.setData([]);
            bbUpperSeries.applyOptions({ visible: false });
            bbMiddleSeries.applyOptions({ visible: false });
            bbLowerSeries.applyOptions({ visible: false });
        }
    }

    // LWMA 표시/숨김 + 데이터 제거
    if (lwmaSeries) {
        if (settings.lwma) {
            lwmaSeries.applyOptions({ visible: true });
        } else {
            lwmaSeries.setData([]);
            lwmaSeries.applyOptions({ visible: false });
        }
    }
    
    // EMA (새로 추가 필요 시)
    if (settings.ema && !this.emaSeries) {
        this.emaSeries = chart.addLineSeries({
            color: '#ff6b6b',
            lineWidth: 2,
            priceLineVisible: false,
            lastValueVisible: false
        });
        // EMA 데이터는 서버에서 받아와야 함 - 임시로 비워둠
    } else if (this.emaSeries) {
        this.emaSeries.applyOptions({ visible: settings.ema });
    }
    
    // SMA (새로 추가 필요 시)
    if (settings.sma && !this.smaSeries) {
        this.smaSeries = chart.addLineSeries({
            color: '#4ecdc4',
            lineWidth: 2,
            priceLineVisible: false,
            lastValueVisible: false
        });
        // SMA 데이터는 서버에서 받아와야 함 - 임시로 비워둠
    } else if (this.smaSeries) {
        this.smaSeries.applyOptions({ visible: settings.sma });
    }
},

/**
     * 차트 타입 변경
     */
    changeChartType(newType) {
        if (typeof ChartTypeManager !== 'undefined') {
            const changed = ChartTypeManager.changeType(newType);
            if (changed) {
                candleSeries = ChartTypeManager.series;
                console.log('[ChartPanel] Chart type changed to:', newType);

                // 차트 타입 버튼 UI 업데이트
                this.updateChartTypeUI(newType);
            }
            return changed;
        }
        return false;
    },

    /**
     * 차트 타입 UI 업데이트
     */
    updateChartTypeUI(activeType) {
        document.querySelectorAll('.chart-type-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.type === activeType);
        });
    },

    /**
     * 현재 차트 타입 가져오기
     */
    getChartType() {
        if (typeof ChartTypeManager !== 'undefined') {
            return ChartTypeManager.getType();
        }
        return 'candlestick';
    },

    _setLayoutVars() {
        const header = document.querySelector('.header');
        const nav = document.querySelector('.bottom-nav');
        const btnBar = document.querySelector('.zm-bottom-bar');
        const symbolRow = document.querySelector('.chart-symbol-row');
        const headerH = header ? header.offsetHeight : 45;
        const navH = nav ? nav.offsetHeight : 52;
        const btnBarH = btnBar ? btnBar.offsetHeight : 48;
        const symbolH = symbolRow ? symbolRow.offsetHeight : 40;
        this._availableHeight = window.innerHeight - headerH - symbolH - btnBarH - navH;
        if (this._availableHeight < 300) this._availableHeight = 300;
    },

    // ========== 타임프레임별 적정 캔들 수 ==========
    getVisibleBarsForTimeframe() {
        const tf = currentTimeframe || 'M5';
        // chart-container 실제 너비 기준으로 판단
        const w = document.getElementById('chart-container')?.clientWidth || window.innerWidth;
        const isMobile = w <= 500;
        const map = {
            'M1':  isMobile ? 50 : 100,
            'M5':  isMobile ? 40 : 80,
            'M15': isMobile ? 35 : 65,
            'M30': isMobile ? 30 : 55,
            'H1':  isMobile ? 25 : 50,
            'H4':  isMobile ? 22 : 40,
            'D1':  isMobile ? 20 : 40,
            'W1':  isMobile ? 18 : 30,
            'MN1': isMobile ? 12 : 20
        };
        return map[tf] || (isMobile ? 35 : 60);
    },

    // ========== 차트 자동 복귀 시스템 ==========
    setupAutoReturn() {
        if (!chart) {
            console.warn('[ChartPanel] setupAutoReturn: chart 없음, 1초 후 재시도');
            setTimeout(() => this.setupAutoReturn(), 1000);
            return;
        }
        const self = this;
        const chartContainer = document.getElementById('chart-container');
        if (!chartContainer) return;

        if (this._chartTouchHandler) {
            chartContainer.removeEventListener('touchstart', this._chartTouchHandler);
            chartContainer.removeEventListener('mousedown', this._chartTouchHandler);
            chartContainer.removeEventListener('wheel', this._chartWheelHandler);
        }

        this._chartTouchHandler = function() {
            self._onChartInteraction();
        };
        this._chartWheelHandler = function() {
            self._onChartInteraction();
        };

        chartContainer.addEventListener('touchstart', this._chartTouchHandler, { passive: true });
        chartContainer.addEventListener('mousedown', this._chartTouchHandler);
        chartContainer.addEventListener('wheel', this._chartWheelHandler, { passive: true });

        try {
            chart.timeScale().subscribeVisibleLogicalRangeChange(() => {
                // loadCandles 중이거나 자동복귀 중이면 무시 (무한루프 방지)
                if (self._isLoadingCandles || self._isAutoReturning) return;
                self._onChartInteraction();
            });
        } catch (e) {
            console.warn('[ChartPanel] subscribeVisibleLogicalRangeChange failed:', e.message);
        }

        console.log('[ChartPanel] ✅ Auto-return system initialized');
    },

    _onChartInteraction() {
        if (this._autoReturnTimer) {
            clearTimeout(this._autoReturnTimer);
            this._autoReturnTimer = null;
        }
        this._autoReturnTimer = setTimeout(() => {
            this.returnToCurrentPrice();
        }, this._autoReturnDelay);
    },

    returnToCurrentPrice() {
        if (!chart || !candleSeries) return;

        // ★★★ 무한루프 방지: 자동복귀 중 플래그 ON ★★★
        this._isAutoReturning = true;

        try {
            const visibleBars = this.getVisibleBarsForTimeframe();

            let candleCount = 0;
            if (typeof ChartTypeManager !== 'undefined' && ChartTypeManager.candleData) {
                candleCount = ChartTypeManager.candleData.length;
            }

            const rightPadding = 6;
            if (candleCount > visibleBars) {
                try {
                    chart.timeScale().setVisibleLogicalRange({
                        from: candleCount - visibleBars,
                        to: candleCount + rightPadding
                    });
                } catch (e) {
                    try { chart.timeScale().scrollToRealTime(); } catch(e2) {}
                }
            } else if (candleCount > 0) {
                try {
                    chart.timeScale().setVisibleLogicalRange({
                        from: 0,
                        to: candleCount + rightPadding
                    });
                } catch (e) {
                    try { chart.timeScale().scrollToRealTime(); } catch(e2) {}
                }
            } else {
                try { chart.timeScale().scrollToRealTime(); } catch(e) {}
            }

            console.log('[ChartPanel] ↩️ Auto-return (bars:', visibleBars, ', candles:', candleCount, ')');
        } catch (e) {
            try { chart.timeScale().scrollToRealTime(); } catch (e2) {}
        }

        this._autoReturnTimer = null;

        // ★★★ 500ms 후 플래그 해제 (setVisibleRange 이벤트 전파 완료 대기) ★★★
        setTimeout(() => {
            this._isAutoReturning = false;
        }, 500);
    },

/**
 * 패널 정리
 */
destroy() {
        if (this._autoReturnTimer) {
            clearTimeout(this._autoReturnTimer);
            this._autoReturnTimer = null;
        }
        const chartContainer = document.getElementById('chart-container');
        if (chartContainer && this._chartTouchHandler) {
            chartContainer.removeEventListener('touchstart', this._chartTouchHandler);
            chartContainer.removeEventListener('mousedown', this._chartTouchHandler);
        }
        if (chartContainer && this._chartWheelHandler) {
            chartContainer.removeEventListener('wheel', this._chartWheelHandler);
        }
        if (this._resizeHandler) {
            window.removeEventListener('resize', this._resizeHandler);
            this._resizeHandler = null;
        }
        if (chart) {
            chart.remove();
            chart = null;
        }
        console.log('[ChartPanel] Destroyed');
    }
};
