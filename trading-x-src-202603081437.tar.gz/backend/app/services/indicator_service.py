# app/services/indicator_service.py
"""
기술적 지표 계산 서비스
demo.py의 캔들 기반 로직으로 계산
"""

import time
import random
from typing import Dict, List, Optional

# MetaAPI 캐시 참조 (lazy import)
def _get_quote_caches():
    from app.api.metaapi_service import quote_price_cache, quote_candle_cache
    return quote_price_cache, quote_candle_cache

# 이전 점수 저장 (스무딩용) - 심볼별
_prev_signal_scores = {}

# 틱 히스토리 (모멘텀 계산용) - 심볼별
_tick_history = {}
_TICK_HISTORY_MAX = 10

# Synthetic 캔들 시가 캐시 (1분마다 갱신)
_synthetic_candle_cache = {
    "minute": 0,
    "open_prices": {}
}

# 종목별 변동률 임계값 (% 기준)
_SYMBOL_THRESHOLDS = {
    "BTCUSD": {"weak": 0.02, "normal": 0.05, "strong": 0.12},
    "ETHUSD": {"weak": 0.03, "normal": 0.07, "strong": 0.15},
    "EURUSD.r": {"weak": 0.005, "normal": 0.015, "strong": 0.04},
    "USDJPY.r": {"weak": 0.005, "normal": 0.015, "strong": 0.04},
    "GBPUSD.r": {"weak": 0.005, "normal": 0.015, "strong": 0.04},
    "AUDUSD.r": {"weak": 0.005, "normal": 0.015, "strong": 0.04},
    "USDCAD.r": {"weak": 0.005, "normal": 0.015, "strong": 0.04},
    "XAUUSD.r": {"weak": 0.01, "normal": 0.03, "strong": 0.08},
    "US100.": {"weak": 0.01, "normal": 0.03, "strong": 0.08},
}
_DEFAULT_THRESHOLD = {"weak": 0.02, "normal": 0.05, "strong": 0.12}


class IndicatorService:
    """기술적 지표 계산 클래스"""
    
    @staticmethod
    def calculate_rsi(closes: List[float], period: int = 14) -> float:
        """RSI 계산"""
        if len(closes) < period + 1:
            return 50.0
        
        gains = []
        losses = []
        
        for i in range(1, len(closes)):
            change = closes[i] - closes[i-1]
            gains.append(max(0, change))
            losses.append(max(0, -change))
        
        avg_gain = sum(gains[-period:]) / period
        avg_loss = sum(losses[-period:]) / period
        
        if avg_loss == 0:
            return 100.0
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    @staticmethod
    def calculate_ema(closes: List[float], period: int) -> float:
        """EMA 계산"""
        if len(closes) < period:
            return closes[-1] if closes else 0
        
        multiplier = 2 / (period + 1)
        ema = sum(closes[:period]) / period
        
        for price in closes[period:]:
            ema = (price - ema) * multiplier + ema
        
        return ema
    
    @staticmethod
    def calculate_macd(closes: List[float], fast: int = 12, slow: int = 26, signal_period: int = 9) -> tuple:
        """MACD 계산"""
        if len(closes) < slow + signal_period:
            return 0, 0
        
        ema_fast = IndicatorService.calculate_ema(closes, fast)
        ema_slow = IndicatorService.calculate_ema(closes, slow)
        macd_line = ema_fast - ema_slow
        
        macd_values = []
        for i in range(slow - 1, len(closes)):
            ef = IndicatorService.calculate_ema(closes[:i+1], fast)
            es = IndicatorService.calculate_ema(closes[:i+1], slow)
            macd_values.append(ef - es)
        
        if len(macd_values) >= signal_period:
            signal_line = sum(macd_values[-signal_period:]) / signal_period
        else:
            signal_line = macd_line
        
        return macd_line, signal_line
    
    @staticmethod
    def calculate_stochastic(closes: List[float], highs: List[float], lows: List[float], 
                            k_period: int = 14, d_period: int = 3) -> tuple:
        """Stochastic 계산"""
        if len(closes) < k_period:
            return 50.0, 50.0
        
        highest_high = max(highs[-k_period:])
        lowest_low = min(lows[-k_period:])
        
        if highest_high == lowest_low:
            k = 50.0
        else:
            k = ((closes[-1] - lowest_low) / (highest_high - lowest_low)) * 100
        
        d = k
        return k, d
    
    @staticmethod
    def calculate_cci(closes: List[float], highs: List[float], lows: List[float], period: int = 20) -> float:
        """CCI 계산"""
        if len(closes) < period:
            return 0
        
        tp_list = [(highs[i] + lows[i] + closes[i]) / 3 for i in range(len(closes))]
        tp = tp_list[-1]
        tp_sma = sum(tp_list[-period:]) / period
        
        mean_deviation = sum(abs(tp_list[i] - tp_sma) for i in range(-period, 0)) / period
        
        if mean_deviation == 0:
            return 0
        
        cci = (tp - tp_sma) / (0.015 * mean_deviation)
        return cci
    
    @staticmethod
    def calculate_williams_r(closes: List[float], highs: List[float], lows: List[float], period: int = 14) -> float:
        """Williams %R 계산"""
        if len(closes) < period:
            return -50.0
        
        highest_high = max(highs[-period:])
        lowest_low = min(lows[-period:])
        
        if highest_high == lowest_low:
            return -50.0
        
        willr = ((highest_high - closes[-1]) / (highest_high - lowest_low)) * -100
        return willr
    
    @staticmethod
    def calculate_adx(closes: List[float], highs: List[float], lows: List[float], period: int = 14) -> tuple:
        """ADX 계산"""
        if len(closes) < period + 1:
            return 25.0, 25.0, 25.0
        
        plus_dm = []
        minus_dm = []
        tr_list = []
        
        for i in range(1, len(closes)):
            high_diff = highs[i] - highs[i-1]
            low_diff = lows[i-1] - lows[i]
            
            plus_dm.append(high_diff if high_diff > low_diff and high_diff > 0 else 0)
            minus_dm.append(low_diff if low_diff > high_diff and low_diff > 0 else 0)
            
            tr = max(highs[i] - lows[i], abs(highs[i] - closes[i-1]), abs(lows[i] - closes[i-1]))
            tr_list.append(tr)
        
        if len(tr_list) < period:
            return 25.0, 25.0, 25.0
        
        atr = sum(tr_list[-period:]) / period
        
        if atr == 0:
            return 25.0, 25.0, 25.0
        
        plus_di = (sum(plus_dm[-period:]) / period) / atr * 100
        minus_di = (sum(minus_dm[-period:]) / period) / atr * 100
        
        dx = abs(plus_di - minus_di) / (plus_di + minus_di) * 100 if (plus_di + minus_di) > 0 else 0
        adx = dx
        
        return adx, plus_di, minus_di
    
    @staticmethod
    def calculate_bollinger(closes: List[float], period: int = 20, std_dev: int = 2) -> tuple:
        """Bollinger Band 계산"""
        if len(closes) < period:
            return closes[-1], closes[-1], closes[-1]
        
        sma = sum(closes[-period:]) / period
        variance = sum((c - sma) ** 2 for c in closes[-period:]) / period
        std = variance ** 0.5
        
        upper = sma + std_dev * std
        lower = sma - std_dev * std
        
        return upper, sma, lower
    
    @staticmethod
    def calculate_lwma(closes: List[float], period: int) -> float:
        """LWMA 계산"""
        if len(closes) < period:
            return closes[-1] if closes else 0
        
        weights = list(range(1, period + 1))
        weighted_sum = sum(w * c for w, c in zip(weights, closes[-period:]))
        weight_total = sum(weights)
        
        return weighted_sum / weight_total
    
    @staticmethod
    def calculate_current_candle_score(symbol: str) -> float:
        """현재 캔들 실시간 분석 (0~100)"""
        score = 50.0
        
        rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M1, 0, 1)
        if rates is None or len(rates) < 1:
            return score
        
        candle = rates[0]
        open_price = candle['open']
        close_price = candle['close']
        high_price = candle['high']
        low_price = candle['low']
        
        if open_price <= 0 or close_price <= 0:
            return score
        
        body = close_price - open_price
        candle_range = high_price - low_price
        if candle_range <= 0:
            candle_range = 0.00001
        
        move_percent = abs(body) / open_price * 10000
        
        if body > 0:
            if move_percent < 5:
                score = 55 + (move_percent / 5) * 10
            elif move_percent < 15:
                score = 65 + ((move_percent - 5) / 10) * 15
            else:
                score = 80 + min((move_percent - 15) / 10, 1.0) * 15
        elif body < 0:
            if move_percent < 5:
                score = 45 - (move_percent / 5) * 10
            elif move_percent < 15:
                score = 35 - ((move_percent - 5) / 10) * 15
            else:
                score = 20 - min((move_percent - 15) / 10, 1.0) * 15
        
        upper_wick = high_price - max(open_price, close_price)
        lower_wick = min(open_price, close_price) - low_price
        
        if candle_range > 0:
            wick_ratio = (lower_wick - upper_wick) / candle_range
            score += wick_ratio * 10
        
        return max(5, min(95, score))
    
    @staticmethod
    def calculate_past_candle_score(symbol: str) -> float:
        """과거 5개 캔들 분석 (0~100)"""
        score = 50.0
        
        rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M1, 0, 6)
        if rates is None or len(rates) < 6:
            return score
        
        bull_count = 0
        bear_count = 0
        total_strength = 0.0
        
        for i in range(5):
            candle = rates[i]
            body = candle['close'] - candle['open']
            body_size = abs(body)
            
            if body > 0:
                bull_count += 1
                total_strength += body_size
            elif body < 0:
                bear_count += 1
                total_strength -= body_size
        
        direction_score = (bull_count - bear_count) * 10.0
        
        avg_price = sum(r['close'] for r in rates[:5]) / 5
        strength_ratio = 0
        if avg_price > 0:
            strength_ratio = total_strength / avg_price * 1000
            strength_ratio = max(-15, min(15, strength_ratio))
        
        continuity_bonus = 0
        if bull_count >= 4:
            continuity_bonus = 10
        elif bear_count >= 4:
            continuity_bonus = -10
        
        score = 50.0 + direction_score + strength_ratio + continuity_bonus
        return max(5, min(95, score))
    
    @staticmethod
    def calculate_all_indicators(symbol: str) -> Dict:
        """
        3요소 시그널 게이지 (캔들 방향 + 틱 모멘텀 + 직전 추세)
        - 1분봉 양봉 → 무조건 Buy (50 이상)
        - 1분봉 음봉 → 무조건 Sell (50 이하)
        - 강한 움직임 → Strong 영역
        - 랜덤 없음, 결정론적 계산
        - score ↔ buy/sell/neutral 100% 동기화
        """
        global _prev_signal_scores, _tick_history, _synthetic_candle_cache

        # MetaAPI 캐시에서 데이터 가져오기
        try:
            quote_price_cache, quote_candle_cache = _get_quote_caches()
        except Exception:
            return {"buy": 33, "sell": 33, "neutral": 34, "score": 50}

        # 현재 tick 가격
        price_data = quote_price_cache.get(symbol, {})
        current_tick = price_data.get("bid", 0)

        if current_tick <= 0:
            return {"buy": 33, "sell": 33, "neutral": 34, "score": 50}

        # ========== 틱 히스토리 저장 (모멘텀용) ==========
        if symbol not in _tick_history:
            _tick_history[symbol] = []
        _tick_history[symbol].append(current_tick)
        if len(_tick_history[symbol]) > _TICK_HISTORY_MAX:
            _tick_history[symbol] = _tick_history[symbol][-_TICK_HISTORY_MAX:]

        # ========== 1분봉 캔들 시가 ==========
        candles = quote_candle_cache.get(symbol, {}).get("M1", [])

        candle_open = 0
        if candles and len(candles) >= 1:
            candle_open = candles[-1].get("open", 0)

        # 캔들이 없으면 synthetic 캔들 사용
        if candle_open == 0 and current_tick > 0:
            current_minute = int(time.time()) // 60
            if _synthetic_candle_cache["minute"] != current_minute:
                _synthetic_candle_cache["minute"] = current_minute
                _synthetic_candle_cache["open_prices"] = {}
            if symbol not in _synthetic_candle_cache["open_prices"]:
                _synthetic_candle_cache["open_prices"][symbol] = current_tick
            candle_open = _synthetic_candle_cache["open_prices"].get(symbol, current_tick)

        # ========== 종목별 임계값 ==========
        thresholds = _SYMBOL_THRESHOLDS.get(symbol, _DEFAULT_THRESHOLD)
        weak_th = thresholds["weak"]
        normal_th = thresholds["normal"]
        strong_th = thresholds["strong"]

        # ========== 요소 1: 현재 캔들 방향 (60%) ==========
        if current_tick > 0 and candle_open > 0:
            change_pct = (current_tick - candle_open) / candle_open * 100
        else:
            change_pct = 0

        # 변동률 → 점수 (결정론적, 랜덤 없음)
        if change_pct >= strong_th:
            candle_score = 90 + min(5, (change_pct - strong_th) / strong_th * 5)
        elif change_pct >= normal_th:
            candle_score = 70 + (change_pct - normal_th) / (strong_th - normal_th) * 20
        elif change_pct >= weak_th:
            candle_score = 55 + (change_pct - weak_th) / (normal_th - weak_th) * 15
        elif change_pct > 0:
            candle_score = 50 + (change_pct / weak_th) * 5
        elif change_pct <= -strong_th:
            candle_score = 10 - min(5, (abs(change_pct) - strong_th) / strong_th * 5)
        elif change_pct <= -normal_th:
            candle_score = 30 - (abs(change_pct) - normal_th) / (strong_th - normal_th) * 20
        elif change_pct <= -weak_th:
            candle_score = 45 - (abs(change_pct) - weak_th) / (normal_th - weak_th) * 15
        elif change_pct < 0:
            candle_score = 50 - (abs(change_pct) / weak_th) * 5
        else:
            candle_score = 50

        candle_score = max(5, min(95, candle_score))

        # ========== 요소 2: 틱 모멘텀 (25%) ==========
        tick_list = _tick_history.get(symbol, [])
        if len(tick_list) >= 3:
            old_tick = tick_list[-min(5, len(tick_list))]
            momentum_pct = (current_tick - old_tick) / current_tick * 10000  # bps
            # 모멘텀 → 점수 보정
            if momentum_pct > 5:
                momentum_score = 75 + min(20, momentum_pct)
            elif momentum_pct > 1:
                momentum_score = 55 + momentum_pct * 4
            elif momentum_pct > 0:
                momentum_score = 50 + momentum_pct * 5
            elif momentum_pct < -5:
                momentum_score = 25 - min(20, abs(momentum_pct))
            elif momentum_pct < -1:
                momentum_score = 45 + momentum_pct * 4
            elif momentum_pct < 0:
                momentum_score = 50 + momentum_pct * 5
            else:
                momentum_score = 50
            momentum_score = max(5, min(95, momentum_score))
        else:
            momentum_score = 50

        # ========== 요소 3: 직전 캔들 추세 (15%) ==========
        trend_score = 50
        if candles and len(candles) >= 4:
            bull_count = 0
            bear_count = 0
            for c in candles[-4:-1]:  # 직전 3개 완성 캔들
                c_open = c.get("open", 0)
                c_close = c.get("close", 0)
                if c_close > c_open:
                    bull_count += 1
                elif c_close < c_open:
                    bear_count += 1

            if bull_count == 3:
                trend_score = 80
            elif bull_count == 2:
                trend_score = 65
            elif bear_count == 3:
                trend_score = 20
            elif bear_count == 2:
                trend_score = 35
            else:
                trend_score = 50

        # ========== 최종 점수 합산 ==========
        raw_score = candle_score * 0.60 + momentum_score * 0.25 + trend_score * 0.15
        raw_score = max(5, min(95, raw_score))

        # ========== 스무딩 (방향 전환 시 빠르게) ==========
        prev_score = _prev_signal_scores.get(symbol, 50.0)

        # 방향 전환 감지 (Buy↔Sell 경계 = 50)
        direction_changed = (prev_score >= 50 and raw_score < 50) or (prev_score < 50 and raw_score >= 50)
        # 강한 변동 감지
        big_move = abs(raw_score - prev_score) > 15

        if direction_changed or big_move:
            # 빠르게 반응
            smooth_factor = 0.7  # 새값 70%
        elif abs(raw_score - prev_score) > 8:
            smooth_factor = 0.5  # 새값 50%
        else:
            smooth_factor = 0.4  # 새값 40%

        final_score = prev_score * (1 - smooth_factor) + raw_score * smooth_factor
        final_score = max(5, min(95, final_score))
        _prev_signal_scores[symbol] = final_score

        # ========== buy/sell/neutral → score에서 직접 산출 ==========
        if final_score >= 80:
            # Strong Buy
            disp_buy = 60 + int((final_score - 80) / 15 * 15)
            disp_sell = max(5, 15 - int((final_score - 80) / 15 * 10))
        elif final_score >= 60:
            # Buy
            disp_buy = 40 + int((final_score - 60) / 20 * 20)
            disp_sell = 30 - int((final_score - 60) / 20 * 15)
        elif final_score >= 50:
            # Weak Buy / Neutral
            disp_buy = 33 + int((final_score - 50) / 10 * 7)
            disp_sell = 33 - int((final_score - 50) / 10 * 3)
        elif final_score >= 40:
            # Weak Sell / Neutral
            disp_sell = 33 + int((50 - final_score) / 10 * 7)
            disp_buy = 33 - int((50 - final_score) / 10 * 3)
        elif final_score >= 20:
            # Sell
            disp_sell = 40 + int((50 - final_score) / 30 * 20)
            disp_buy = 30 - int((50 - final_score) / 30 * 15)
        else:
            # Strong Sell
            disp_sell = 60 + int((20 - final_score) / 15 * 15)
            disp_buy = max(5, 15 - int((20 - final_score) / 15 * 10))

        disp_buy = max(5, min(75, disp_buy))
        disp_sell = max(5, min(75, disp_sell))
        disp_neutral = 100 - disp_buy - disp_sell
        disp_neutral = max(5, disp_neutral)

        # 합계 100 보장
        total = disp_buy + disp_sell + disp_neutral
        if total != 100:
            disp_neutral = 100 - disp_buy - disp_sell

        return {
            "buy": disp_buy,
            "sell": disp_sell,
            "neutral": disp_neutral,
            "score": round(final_score, 1)
        }
    
    @staticmethod
    def calculate_chart_indicators(candles: List[Dict], closes: List[float], 
                                   highs: List[float], lows: List[float]) -> Dict:
        """차트용 인디케이터 계산"""
        n = len(closes)
        if n < 20:
            return {}
        
        bb_period = 20
        bb_std = 2
        bb_upper = []
        bb_middle = []
        bb_lower = []
        
        for i in range(n):
            if i < bb_period - 1:
                bb_upper.append(None)
                bb_middle.append(None)
                bb_lower.append(None)
            else:
                window = closes[i - bb_period + 1:i + 1]
                sma = sum(window) / bb_period
                variance = sum((x - sma) ** 2 for x in window) / bb_period
                std = variance ** 0.5
                bb_middle.append({"time": candles[i]["time"], "value": sma})
                bb_upper.append({"time": candles[i]["time"], "value": sma + bb_std * std})
                bb_lower.append({"time": candles[i]["time"], "value": sma - bb_std * std})
        
        lwma_period = 20
        lwma = []
        for i in range(n):
            if i < lwma_period - 1:
                lwma.append(None)
            else:
                window = closes[i - lwma_period + 1:i + 1]
                weights = list(range(1, lwma_period + 1))
                weighted_sum = sum(w * c for w, c in zip(weights, window))
                weight_total = sum(weights)
                lwma.append({"time": candles[i]["time"], "value": weighted_sum / weight_total})
        
        return {
            "bb_upper": [x for x in bb_upper if x],
            "bb_middle": [x for x in bb_middle if x],
            "bb_lower": [x for x in bb_lower if x],
            "lwma": [x for x in lwma if x]
        }


# 싱글톤 인스턴스
indicator_service = IndicatorService()