/**
 * Quick & Easy — Tick Chart (Area Chart)
 * lightweight-charts + MetaAPI 실시간 틱
 */

const QeTickChart = {
    chart: null,
    areaSeries: null,
    tickData: [],
    maxTicks: 200,          // 화면에 보이는 최대 포인트 (120틱 초기 + 여유)
    lastPrice: 0,
    openPrice: 0,           // 히스토리 첫 가격 (fallback)
    dailyOpen: 0,          // ★ D1 캔들 시가 (실제 일일 등락용)
    prevPrice: 0,           // 보간용
    targetPrice: 0,
    animFrameId: null,
    animating: false,
    priceLine: null,         // 진입가격 라인
    bepPriceLine: null,      // BEP(손익분기점) 라인
    tpPriceLine: null,       // TP 라인
    slPriceLine: null,       // SL 라인
    _autoReturnTimer: null,  // 자동복귀 타이머
    _userInteracting: false, // 사용자 조작 중
    _customPriceRange: null, // 줌아웃 시 커스텀 가격 범위 (플래그)
    initialized: false,
    _loadingHistory: false,  // 히스토리 로딩 중 플래그
    _progressCanvas: null,   // SL/TP 진행도 바 캔버스
    _entryData: null,        // { price, side, tp, sl }
    _totalSeriesCount: 0,    // ★ 시리즈 실제 데이터 수 (tickData와 별도 추적)
    _entryOverlay: null,     // ◉ BUY/SELL 커스텀 라벨
    _bepOverlay: null,       // BEP 커스텀 라벨
    _tpOverlay: null,        // Win 커스텀 라벨
    _slOverlay: null,        // Lose 커스텀 라벨

    // 종목별 카테고리
    CATEGORIES: {
        'BTCUSD': 'Crypto Currency',
        'ETHUSD': 'Crypto Currency',
        'EURUSD.r': 'Forex',
        'USDJPY.r': 'Forex',
        'GBPUSD.r': 'Forex',
        'AUDUSD.r': 'Forex',
        'USDCAD.r': 'Forex',
        'XAUUSD.r': 'Metals',
        'US100.': 'Indices'
    },

    // 종목별 소수점
    DECIMALS: {
        'BTCUSD': 2,
        'ETHUSD': 2,
        'EURUSD.r': 5,
        'USDJPY.r': 3,
        'GBPUSD.r': 5,
        'XAUUSD.r': 2,
        'US100.': 2
    },

    init() {
        if (this.initialized) return;
        const container = document.getElementById('qeChartContainer');
        if (!container || typeof LightweightCharts === 'undefined') {
            console.warn('[QeTickChart] container 또는 LightweightCharts 없음');
            return;
        }

        this.chart = LightweightCharts.createChart(container, {
            layout: {
                background: { type: 'solid', color: '#0a0a0f' },
                textColor: 'rgba(255, 255, 255, 0.4)',
                fontSize: 9
            },
            grid: {
                vertLines: { color: 'transparent' },
                horzLines: { color: 'transparent' }
            },
            rightPriceScale: {
                borderColor: 'rgba(255, 255, 255, 0.06)',
                scaleMargins: { top: 0.1, bottom: 0.1 },
                minimumWidth: 100
            },
            timeScale: {
                borderColor: 'rgba(255, 255, 255, 0.06)',
                timeVisible: true,
                secondsVisible: true,
                rightOffset: 8,
                fixLeftEdge: false,
                fixRightEdge: false
            },
            crosshair: {
                mode: LightweightCharts.CrosshairMode.Normal,
                vertLine: { color: 'rgba(255, 255, 255, 0.15)', width: 1, style: 2 },
                horzLine: { color: 'rgba(255, 255, 255, 0.15)', width: 1, style: 2 }
            },
            handleScroll: true,
            handleScale: true
        });

        this.areaSeries = this.chart.addAreaSeries({
            topColor: 'rgba(0, 210, 255, 0.25)',
            bottomColor: 'rgba(0, 210, 255, 0.02)',
            lineColor: '#00d2ff',
            lineWidth: 2,
            crosshairMarkerVisible: true,
            crosshairMarkerRadius: 4,
            crosshairMarkerBorderColor: '#00d2ff',
            crosshairMarkerBackgroundColor: '#0a0a0f',
            priceFormat: {
                type: 'price',
                precision: this.getDecimals(),
                minMove: Math.pow(10, -this.getDecimals())
            },
            // ★ 한 번만 설정, 절대 제거/교체 안 함 (3.8.0 안정성)
            autoscaleInfoProvider: (baseImpl) => {
                if (this._customPriceRange) {
                    return { priceRange: this._customPriceRange };
                }
                return baseImpl ? baseImpl() : null;
            }
        });

        // 사용자 조작 감지 → 5초 후 자동 현재가 복귀
        this.chart.timeScale().subscribeVisibleTimeRangeChange(() => {
            this.refreshPulsePosition();  // ★ 스크롤/줌 시 펄스 즉시 추적
            if (this._entryOverlay) this.updateEntryOverlay();
            if (this._entryData) this.drawProgressBars();
            if (this._userInteracting) return;
            this._userInteracting = true;
            if (this._autoReturnTimer) clearTimeout(this._autoReturnTimer);
            this._autoReturnTimer = setTimeout(() => {
                this._userInteracting = false;
                this.resetChartView();
            }, 5000);
        });

        // ★ requestAnimationFrame 루프로 오버레이/진행바/펄스 실시간 추적
        this._rafTrackingId = null;
        const trackOverlays = () => {
            this.refreshPulsePosition();  // ★ 매 프레임 펄스 위치 갱신
            if (this._entryOverlay) this.updateEntryOverlay();
            if (this._entryData) this.drawProgressBars();
            // ★ 항상 루프 유지 (펄스 마커 추적 필요)
            this._rafTrackingId = requestAnimationFrame(trackOverlays);
        };
        // 포지션 생성 시 루프 시작을 위한 메서드
        this._startTracking = () => {
            if (!this._rafTrackingId) {
                this._rafTrackingId = requestAnimationFrame(trackOverlays);
            }
        };
        // ★ 초기화 시 바로 RAF 루프 시작 (펄스 마커 항상 추적)
        this._startTracking();

        // 터치/마우스 조작 감지
        container.addEventListener('touchstart', () => {
            this._userInteracting = true;
            this._zoomAnimating = false; // 줌인 애니메이션 중단
            if (this._autoReturnTimer) clearTimeout(this._autoReturnTimer);
        }, { passive: true });
        container.addEventListener('touchend', () => {
            this._autoReturnTimer = setTimeout(() => {
                this._userInteracting = false;
                this.resetChartView();
            }, 5000);
        }, { passive: true });
        container.addEventListener('mouseup', () => {
            if (this._autoReturnTimer) clearTimeout(this._autoReturnTimer);
            this._autoReturnTimer = setTimeout(() => {
                this._userInteracting = false;
                this.resetChartView();
            }, 5000);
        });

        // 리사이즈 대응
        window.addEventListener('resize', () => this.resize());
        window.addEventListener('orientationchange', () => {
            setTimeout(() => this.resize(), 300);
        });

        this.initialized = true;
        console.log('[QeTickChart] 초기화 완료');

        // ★ 초기 히스토리 로딩 (차트 빈 화면 방지)
        this.loadInitialHistory().then(() => {
            // ★ pending 진입 라인이 있으면 히스토리 로딩 후 그리기
            if (this._pendingEntryLine) {
                const p = this._pendingEntryLine;
                console.log('[QeTickChart] ★ pending 라인 그리기:', p);
                this.showEntryLine(p.price, p.side, p.tp, p.sl, p.bep);
                this._pendingEntryLine = null;
            }
        });
    },

    async loadInitialHistory() {
        this._loadingHistory = true;

        // ★ 이전 줌인 시퀀스 전체 취소 (fitContent + 줌인 모두)
        this._zoomAnimating = false;
        if (this._initialZoomTimer) { clearTimeout(this._initialZoomTimer); this._initialZoomTimer = null; }
        if (this._initialZoomSequence) { clearTimeout(this._initialZoomSequence); this._initialZoomSequence = null; }

        // ★ 요청 ID: 중복 호출 시 이전 요청 결과 무시
        if (!this._historyRequestId) this._historyRequestId = 0;
        const requestId = ++this._historyRequestId;

        // ★ 종목 변경 시 이전 데이터 즉시 클리어 (점프 방지)
        this.tickData = [];
        this._totalSeriesCount = 0;  // ★ 카운트 리셋
        if (this.areaSeries) {
            this.areaSeries.setData([]);
        }

        // ★ 안전장치: 5초 후 강제 해제 (API 지연/실패 대비)
        this._loadingTimeout = setTimeout(() => {
            if (this._loadingHistory) {
                console.warn('[QeTickChart] ⚠️ 히스토리 로딩 타임아웃 → 강제 해제');
                this._loadingHistory = false;
            }
        }, 5000);
        const symbol = window.currentSymbol || 'BTCUSD';
        const KST_OFFSET = 9 * 3600;
        try {
            if (typeof apiCall !== 'function') return;
            const data = await apiCall('/mt5/candles/' + symbol + '?timeframe=M1&count=30');
            if (data && data.candles && data.candles.length > 0) {
                const historyTicks = [];
                const candles = data.candles.slice(-30);
                candles.forEach(c => {
                    // 각 캔들의 open, high, low, close를 4개 틱으로 분해
                    const baseTime = c.time + KST_OFFSET;
                    historyTicks.push({ time: baseTime, value: c.open });
                    historyTicks.push({ time: baseTime + 15, value: c.high });
                    historyTicks.push({ time: baseTime + 30, value: c.low });
                    historyTicks.push({ time: baseTime + 45, value: c.close });
                });
                // 시간순 정렬 + 중복 제거
                historyTicks.sort((a, b) => a.time - b.time);
                const unique = [];
                let lastTime = 0;
                historyTicks.forEach(t => {
                    if (t.time > lastTime) {
                        unique.push(t);
                        lastTime = t.time;
                    }
                });

                // ★ 이전 요청이면 무시 (두 번째 호출만 실행)
                if (this._historyRequestId !== requestId) return;

                if (unique.length > 0 && this.areaSeries) {
                    this.areaSeries.setData(unique);
                    this.tickData = unique;
                    this._totalSeriesCount = unique.length;  // ★ 히스토리 카운트 초기화
                    this.lastPrice = unique[unique.length - 1].value;
                    this.openPrice = unique[0].value;
                    this.prevPrice = this.lastPrice;
                    this._lastHistoryTime = unique[unique.length - 1].time; // ★ 히스토리 마지막 시간 기록
                    console.log('[QeTickChart] ★ 초기 히스토리 로딩:', unique.length, '틱');
                    // ★ D1 캔들에서 당일 시가 로딩
                    try {
                        const d1 = await apiCall('/mt5/candles/' + symbol + '?timeframe=D1&count=1');
                        if (d1 && d1.candles && d1.candles.length > 0) {
                            this.dailyOpen = d1.candles[d1.candles.length - 1].open;
                            window._dailyOpen = window._dailyOpen || {};
                            window._dailyOpen[symbol] = this.dailyOpen;
                            console.log('[QeTickChart] ★ D1 시가:', this.dailyOpen);
                        }
                    } catch(e) { console.warn('[QeTickChart] D1 시가 로딩 실패:', e); }

                    // ★ fitContent + 줌인을 하나의 취소 가능한 시퀀스로 통합
                    if (this._initialZoomSequence) clearTimeout(this._initialZoomSequence);
                    this._initialZoomSequence = setTimeout(() => {
                        if (!this.chart) return;
                        this.chart.timeScale().fitContent();

                        if (this._initialZoomTimer) clearTimeout(this._initialZoomTimer);
                        this._initialZoomTimer = setTimeout(() => {
                            if (!this.chart || !this.tickData || this.tickData.length === 0) return;
                            if (this._zoomAnimating) return;

                            this._zoomAnimating = true;
                            const totalBars = this.tickData.length;
                            const targetVisibleBars = Math.max(15, Math.min(50, totalBars));
                            const startVisibleBars = totalBars;
                            const rightOffset = 8;

                            const duration = 1500;
                            const steps = 50;
                            const stepTime = duration / steps;
                            let currentStep = 0;

                            const easeInOutCubic = (t) => {
                                return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
                            };

                            const animateZoom = () => {
                                if (!this._zoomAnimating) return;
                                currentStep++;
                                const progress = easeInOutCubic(currentStep / steps);
                                const currentVisibleBars = Math.round(
                                    startVisibleBars + (targetVisibleBars - startVisibleBars) * progress
                                );

                                try {
                                    this.chart.timeScale().setVisibleLogicalRange({
                                        from: totalBars - currentVisibleBars,
                                        to: totalBars + rightOffset
                                    });
                                } catch(e) {}

                                if (currentStep < steps) {
                                    setTimeout(animateZoom, stepTime);
                                } else {
                                    this._zoomAnimating = false;
                                    console.log('[QeTickChart] ★ 줌인 애니메이션 완료');
                                    // ★ following mode 재활성화 → 현재가가 항상 rightOffset 위치 유지
                                    try { this.chart.timeScale().scrollToPosition(8, false); } catch(e) {}
                                    if (this._entryData && this._entryData.tp && this._entryData.sl) {
                                        this.zoomToShowTPSL(this._entryData.price, this._entryData.tp, this._entryData.sl);
                                    }
                                }
                            };

                            animateZoom();
                        }, 2000);
                    }, 50);
                }
            }
        } catch (e) {
            console.warn('[QeTickChart] 히스토리 로딩 실패:', e);
        } finally {
            this._loadingHistory = false;
            if (this._loadingTimeout) {
                clearTimeout(this._loadingTimeout);
                this._loadingTimeout = null;
            }
            // ★ 장 종료 시에도 마지막 가격 즉시 표시 (틱 없이도 유지)
            if (this.lastPrice > 0) {
                this.updateQuote(this.lastPrice);
            }
        }
    },

    getDecimals() {
        const symbol = window.currentSymbol || 'BTCUSD';
        return this.DECIMALS[symbol] || 2;
    },

    // ========== 틱 데이터 추가 (보간 애니메이션) ==========
    addTick(price) {
        if (!this.areaSeries || price <= 0) return;
        if (this._loadingHistory) return; // 히스토리 로딩 중 무시

        // 첫 틱이면 openPrice 설정
        if (this.openPrice === 0) {
            this.openPrice = price;
        }

        this.prevPrice = this.lastPrice || price;
        this.targetPrice = price;

        // 보간 시작
        if (!this.animating) {
            this.animating = true;
            this.interpolate();
        }

        // 호가 업데이트 (즉시)
        this.updateQuote(price);
        this.updateColor(price);

        // Win/Lose 실시간 업데이트 (틱마다, 깜빡임 없음)
        if (typeof QuickEasyPanel !== 'undefined' && QuickEasyPanel._posEntryPrice > 0) {
            QuickEasyPanel.updateWinLose();
        }
    },

    // ========== 60fps 보간 애니메이션 ==========
    interpolate() {
        if (!this.areaSeries) { this.animating = false; return; }

        const diff = this.targetPrice - (this.lastPrice || this.targetPrice);
        const step = diff * 0.08;  // 이징: 30%씩 접근

        if (Math.abs(diff) < 0.001) {
            // 도착 — 최종값 적용
            this.lastPrice = this.targetPrice;
            this.commitTick(this.targetPrice);
            this.animating = false;
            return;
        }

        this.lastPrice = (this.lastPrice || this.targetPrice) + step;
        this.commitTick(this.lastPrice);

        this.animFrameId = requestAnimationFrame(() => this.interpolate());
    },

    // ========== 차트에 실제 데이터 반영 ==========
    commitTick(price) {
        const now = Math.floor(Date.now() / 1000) + 9 * 3600; // KST 표시

        // ★ 시간 역전/중복 방지: 마지막보다 작거나 같으면 update만 (새 포인트 추가 안 함)
        if (this.tickData.length > 0) {
            const lastTime = this.tickData[this.tickData.length - 1].time;
            if (now <= lastTime) {
                // 같은 초: 가격만 업데이트
                this.tickData[this.tickData.length - 1].value = price;
                this.areaSeries.update({ time: lastTime, value: price });
                this.updatePulse(lastTime, price);
                if (this._entryData) this.drawProgressBars();
                return;
            }
        }

        this.tickData.push({ time: now, value: price });
        this._totalSeriesCount++;  // ★ 시리즈 실제 카운트

        this.areaSeries.update({ time: now, value: price });

        // 최대 틱 수 유지
        if (this.tickData.length > this.maxTicks * 2) {
            this.tickData = this.tickData.slice(-this.maxTicks);
        }

        // 펄스 마커 위치 업데이트
        this.updatePulse(now, price);

        // ★ following mode 유지: 사용자 조작 중 아닐 때 강제 스크롤
        if (!this._userInteracting && !this._zoomAnimating) {
            try { this.chart.timeScale().scrollToPosition(8, false); } catch(e) {}
        }

        // ★ 진입가 오버레이 위치 업데이트
        if (this._entryOverlay) this.updateEntryOverlay();

        // ★ SL/TP 진행도 바 업데이트
        if (this._entryData) this.drawProgressBars();
    },

    // ========== 현재가 펄스 마커 ==========
    updatePulse(time, price) {
        const marker = document.getElementById('qePulseMarker');
        if (!marker || !this.chart || !this.areaSeries) return;

        try {
            const timeCoord = this.chart.timeScale().timeToCoordinate(time);
            const priceCoord = this.areaSeries.priceToCoordinate(price);

            if (timeCoord !== null && priceCoord !== null && timeCoord > 0 && priceCoord > 0) {
                marker.style.display = 'block';
                marker.style.transform = 'translate3d(' + (timeCoord - 3.5) + 'px, ' + (priceCoord - 3.5) + 'px, 0)';
            } else {
                marker.style.display = 'none';
            }
        } catch (e) {
            marker.style.display = 'none';
        }
    },

    // ★ 매 프레임 펄스 위치 재계산 (줌/스크롤 시 잔상 방지)
    refreshPulsePosition() {
        const marker = document.getElementById('qePulseMarker');
        if (!marker || !this.chart || !this.areaSeries) return;
        if (!this.tickData || this.tickData.length === 0) return;

        try {
            const last = this.tickData[this.tickData.length - 1];
            const timeCoord = this.chart.timeScale().timeToCoordinate(last.time);
            const priceCoord = this.areaSeries.priceToCoordinate(last.value);

            if (timeCoord !== null && priceCoord !== null && timeCoord > 0 && priceCoord > 0) {
                marker.style.display = 'block';
                marker.style.transform = 'translate3d(' + (timeCoord - 3.5) + 'px, ' + (priceCoord - 3.5) + 'px, 0)';
            } else {
                marker.style.display = 'none';
            }
        } catch (e) {
            marker.style.display = 'none';
        }
    },

    // ========== 호가 영역 업데이트 ==========
    updateQuote(price) {
        const symbol = window.currentSymbol || 'BTCUSD';
        const decimals = this.getDecimals();

        // 현재가
        const priceEl = document.getElementById('qeQuotePrice');
        if (priceEl) {
            priceEl.textContent = price.toLocaleString('en-US', {
                minimumFractionDigits: decimals,
                maximumFractionDigits: decimals
            });
        }

        // 등락 (★ D1 시가 우선, fallback: 히스토리 첫 가격)
        const refPrice = this.dailyOpen > 0 ? this.dailyOpen : this.openPrice;
        if (refPrice > 0) {
            const change = price - refPrice;
            const changePct = (change / refPrice) * 100;
            const sign = change >= 0 ? '+' : '';
            const isNeg = change < 0;

            const changeEl = document.getElementById('qeChangeValue');
            const pctEl = document.getElementById('qeChangePct');
            if (changeEl) {
                changeEl.textContent = sign + change.toFixed(decimals);
                changeEl.className = 'qe-change-value' + (isNeg ? ' negative' : '');
            }
            if (pctEl) {
                pctEl.textContent = '(' + sign + changePct.toFixed(2) + '%)';
                pctEl.className = 'qe-change-pct' + (isNeg ? ' negative' : '');
            }
        }

        // 종목 정보
        const symbolEl = document.getElementById('qeInfoSymbol');
        const catEl = document.getElementById('qeInfoCategory');
        if (symbolEl) symbolEl.textContent = symbol.replace('.r', '').replace('.', '');
        if (catEl) catEl.textContent = this.CATEGORIES[symbol] || 'Market';

        // ★ 장 운영 상태 (isCurrentMarketClosed — MT5 크로스 체크 포함)
        const statusEl = document.getElementById('qeInfoStatus');
        if (statusEl) {
            const isOpen = typeof isCurrentMarketClosed === 'function'
                ? !isCurrentMarketClosed(symbol) : true;
            if (isOpen) {
                statusEl.style.display = 'none';
            } else {
                statusEl.style.display = 'inline-flex';
                statusEl.style.alignItems = 'center';
                statusEl.style.lineHeight = '1';
                statusEl.style.verticalAlign = 'middle';
                statusEl.style.background = '#ff4d5a';
                statusEl.style.width = 'auto';
                statusEl.style.height = 'auto';
                statusEl.style.borderRadius = '3px';
                statusEl.style.padding = '0px 5px';
                statusEl.style.paddingTop = '1px';
                statusEl.style.fontSize = '9px';
                statusEl.style.color = '#fff';
                statusEl.style.fontWeight = '700';
                statusEl.style.letterSpacing = '0.3px';
                statusEl.style.boxShadow = '0 0 4px rgba(255,77,90,0.5)';
                statusEl.textContent = 'CLOSED';
            }
        }
    },

    // ========== 마켓 상태 + 심볼 정보 독립 업데이트 ==========
    // addTick 차단(장 종료)과 무관하게 항상 호출 가능
    refreshMarketStatus(symbol) {
        const sym = symbol || window.currentSymbol || 'BTCUSD';
        // 심볼 텍스트
        const symbolEl = document.getElementById('qeInfoSymbol');
        if (symbolEl) symbolEl.textContent = sym.replace('.r', '').replace('.', '');
        // 카테고리
        const catEl = document.getElementById('qeInfoCategory');
        if (catEl) catEl.textContent = this.CATEGORIES[sym] || 'Market';
        // 장 운영 상태
        const statusEl = document.getElementById('qeInfoStatus');
        if (statusEl) {
            const isOpen = typeof isCurrentMarketClosed === 'function'
                ? !isCurrentMarketClosed(sym) : true;
            if (isOpen) {
                statusEl.style.display = 'none';
                statusEl.textContent = '';
            } else {
                statusEl.style.display = 'inline-flex';
                statusEl.style.alignItems = 'center';
                statusEl.style.lineHeight = '1';
                statusEl.style.verticalAlign = 'middle';
                statusEl.style.background = '#ff4d5a';
                statusEl.style.width = 'auto';
                statusEl.style.height = 'auto';
                statusEl.style.borderRadius = '3px';
                statusEl.style.padding = '0px 5px';
                statusEl.style.paddingTop = '1px';
                statusEl.style.fontSize = '9px';
                statusEl.style.color = '#fff';
                statusEl.style.fontWeight = '700';
                statusEl.style.letterSpacing = '0.3px';
                statusEl.style.boxShadow = '0 0 4px rgba(255,77,90,0.5)';
                statusEl.textContent = 'CLOSED';
            }
        }
    },

    // ========== 색상 (항상 초록) ==========
    updateColor(price) {
        // 항상 초록색 유지
    },

    // ========== 진입가격 + SL/TP 라인 ==========
    showEntryLine(price, side, tpPrice, slPrice, bepPrice) {
        this.removeEntryLine();
        if (!this.areaSeries) return;

        const sideColor = side === 'buy' ? '#00d4a4' : '#ff4d5a';
        const label = side === 'buy' ? '◉ BUY' : '◉ SELL';

        // 진입가 점선 (호가 박스 제거)
        this.priceLine = this.areaSeries.createPriceLine({
            price: price,
            color: sideColor,
            lineWidth: 1,
            lineStyle: 2,
            axisLabelVisible: false,
            title: ''
        });

        // ★ 커스텀 ◉ BUY/SELL 오버레이
        if (this._entryOverlay) this._entryOverlay.remove();
        const wrap = document.getElementById('qeChartWrap');
        if (wrap) {
            const ov = document.createElement('div');
            ov.className = 'qe-entry-overlay';
            ov.innerHTML = '<span class="qe-entry-dot" style="color:' + sideColor + '">◉</span> <span class="qe-entry-label">' + (side === 'buy' ? 'BUY' : 'SELL') + '</span>';
            ov.style.cssText = 'position:absolute;right:65px;pointer-events:none;z-index:6;' +
                'font-size:9px;font-weight:700;letter-spacing:0.5px;' +
                'color:' + sideColor + ';' +
                'background:rgba(10,10,15,0.7);padding:1px 5px;border-radius:3px;' +
                'white-space:nowrap;transform:translateY(-50%);';
            wrap.appendChild(ov);
            this._entryOverlay = ov;
            this._entryOverlayPrice = price;
            this.updateEntryOverlay();
        }

        // ★ BEP(손익분기점) 라인 — 밝은 회색 점선
        if (bepPrice && bepPrice > 0 && bepPrice !== price) {
            this.bepPriceLine = this.areaSeries.createPriceLine({
                price: bepPrice,
                color: '#aaaaaa',
                lineWidth: 1,
                lineStyle: 2,
                axisLabelVisible: false,
                title: ''
            });
            // ★ BEP 커스텀 오버레이
            if (this._bepOverlay) this._bepOverlay.remove();
            if (wrap) {
                const bepOv = document.createElement('div');
                bepOv.className = 'qe-bep-overlay';
                bepOv.innerHTML = '<span style="color:#aaa;font-size:8px;">⬥</span> <span style="color:#ccc;font-weight:700;letter-spacing:0.5px;">BEP</span>';
                bepOv.style.cssText = 'position:absolute;right:65px;pointer-events:none;z-index:5;' +
                    'font-size:9px;font-weight:700;letter-spacing:0.5px;' +
                    'color:#cccccc;' +
                    'background:rgba(10,10,15,0.7);padding:1px 5px;border-radius:3px;' +
                    'white-space:nowrap;transform:translateY(-50%);';
                wrap.appendChild(bepOv);
                this._bepOverlay = bepOv;
                this._bepOverlayPrice = bepPrice;
            }
            console.log('[QeTickChart] BEP 라인 생성:', bepPrice);
        }

        // TP 라인 (호가에 초록 가격 표시)
        if (tpPrice && tpPrice > 0) {
            this.tpPriceLine = this.areaSeries.createPriceLine({
                price: tpPrice,
                color: '#00d4a4',
                lineWidth: 1,
                lineStyle: 0,
                axisLabelVisible: true,
                title: ''
            });
            // ★ Win 커스텀 오버레이 (호가 왼쪽 바깥)
            if (this._tpOverlay) this._tpOverlay.remove();
            if (wrap) {
                const tpOv = document.createElement('div');
                tpOv.className = 'qe-tp-overlay';
                tpOv.textContent = 'Win';
                tpOv.style.cssText = 'position:absolute;right:65px;pointer-events:none;z-index:6;' +
                    'font-size:8px;font-weight:700;letter-spacing:0.5px;' +
                    'color:#00d4a4;' +
                    'background:rgba(10,10,15,0.85);border:1px solid rgba(0,212,164,0.5);' +
                    'padding:1px 6px;border-radius:3px;' +
                    'white-space:nowrap;transform:translateY(-50%);';
                wrap.appendChild(tpOv);
                this._tpOverlay = tpOv;
                this._tpOverlayPrice = tpPrice;
            }
        }

        // SL 라인 (호가에 빨강 가격 표시)
        if (slPrice && slPrice > 0) {
            this.slPriceLine = this.areaSeries.createPriceLine({
                price: slPrice,
                color: '#ff4d5a',
                lineWidth: 1,
                lineStyle: 0,
                axisLabelVisible: true,
                title: ''
            });
            // ★ Lose 커스텀 오버레이 (호가 왼쪽 바깥)
            if (this._slOverlay) this._slOverlay.remove();
            if (wrap) {
                const slOv = document.createElement('div');
                slOv.className = 'qe-sl-overlay';
                slOv.textContent = 'Lose';
                slOv.style.cssText = 'position:absolute;right:65px;pointer-events:none;z-index:6;' +
                    'font-size:8px;font-weight:700;letter-spacing:0.5px;' +
                    'color:#ff4d5a;' +
                    'background:rgba(10,10,15,0.85);border:1px solid rgba(255,77,90,0.5);' +
                    'padding:1px 6px;border-radius:3px;' +
                    'white-space:nowrap;transform:translateY(-50%);';
                wrap.appendChild(slOv);
                this._slOverlay = slOv;
                this._slOverlayPrice = slPrice;
            }
        }

        // 진입 시 줌아웃 연출: SL/TP 전체 보이도록
        if (tpPrice && slPrice) {
            this.zoomToShowTPSL(price, tpPrice, slPrice);
        }

        // ★ SL/TP 진행도 바 시작
        this._entryData = { price, side, tp: tpPrice, sl: slPrice, bep: bepPrice || price };
        this.initProgressCanvas();
        this.drawProgressBars();

        // ★ rAF 트래킹 루프 시작
        if (this._startTracking) this._startTracking();

        // ★★★ 최초 진입 시 라인 표시 보장: Y축 강제 업데이트 ★★★
        // 문제: showEntryLine() 호출 시점에 차트 Y축 범위가 아직 라인 가격을 포함하지 않을 수 있음
        // 해결: 약간의 지연 후 Y축만 조정 (X축은 건드리지 않음!)
        if (this.chart && tpPrice && slPrice) {
            setTimeout(() => {
                if (!this.chart || !this.areaSeries) return;
                // Y축 범위 재설정 (라인 포함) - X축은 현재 뷰 유지
                this.zoomToShowTPSL(price, tpPrice, slPrice);
                // 오버레이 위치 업데이트
                this.updateEntryOverlay();
                this.drawProgressBars();
            }, 100);
        }

        // ★ SL/TP 표시 후 부드럽게 50초 뷰로 줌인
        setTimeout(() => {
            if (!this.chart || !this.tickData || this.tickData.length === 0) return;

            // ★ 진행 중인 초기 줌인 취소하고 포지션 줌인으로 전환
            if (this._initialZoomTimer) { clearTimeout(this._initialZoomTimer); this._initialZoomTimer = null; }
            if (this._initialZoomSequence) { clearTimeout(this._initialZoomSequence); this._initialZoomSequence = null; }
            this._zoomAnimating = false;

            this._zoomAnimating = true;
            const totalBars = this.tickData.length;
            const targetVisibleBars = Math.max(15, Math.min(50, totalBars));
            const rightOffset = 8;

            // 현재 보이는 범위 가져오기
            let currentVisibleBars = totalBars; // fallback
            try {
                const visibleRange = this.chart.timeScale().getVisibleLogicalRange();
                if (visibleRange) {
                    currentVisibleBars = Math.round(visibleRange.to - visibleRange.from);
                }
            } catch(e) {}

            // 이미 목표와 비슷하면 애니메이션 불필요
            if (Math.abs(currentVisibleBars - targetVisibleBars) < 5) {
                this._zoomAnimating = false;
                return;
            }

            const startBars = currentVisibleBars;
            const duration = 800; // 0.8초
            const steps = 30;
            const stepTime = duration / steps;
            let currentStep = 0;

            const easeInOutCubic = (t) => {
                return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
            };

            const animateToView = () => {
                if (!this._zoomAnimating) return;
                currentStep++;
                const progress = easeInOutCubic(currentStep / steps);
                const nowBars = Math.round(
                    startBars + (targetVisibleBars - startBars) * progress
                );

                try {
                    this.chart.timeScale().setVisibleLogicalRange({
                        from: totalBars - nowBars,
                        to: totalBars + rightOffset
                    });
                } catch(e) {}

                if (currentStep < steps) {
                    setTimeout(animateToView, stepTime);
                } else {
                    this._zoomAnimating = false;
                }
            };

            animateToView();
        }, 500); // SL/TP 보여준 후 0.5초 뒤 줌인 시작 (번쩍임 방지)
    },

    removeEntryLine() {
        if (this.priceLine && this.areaSeries) {
            this.areaSeries.removePriceLine(this.priceLine);
            this.priceLine = null;
        }
        if (this.tpPriceLine && this.areaSeries) {
            this.areaSeries.removePriceLine(this.tpPriceLine);
            this.tpPriceLine = null;
        }
        if (this.slPriceLine && this.areaSeries) {
            this.areaSeries.removePriceLine(this.slPriceLine);
            this.slPriceLine = null;
        }
        if (this.bepPriceLine && this.areaSeries) {
            this.areaSeries.removePriceLine(this.bepPriceLine);
            this.bepPriceLine = null;
        }
        // ★ 오버레이 제거 + 트래킹 중지
        if (this._rafTrackingId) {
            cancelAnimationFrame(this._rafTrackingId);
            this._rafTrackingId = null;
        }
        if (this._entryOverlay) {
            this._entryOverlay.remove();
            this._entryOverlay = null;
        }
        if (this._tpOverlay) {
            this._tpOverlay.remove();
            this._tpOverlay = null;
        }
        if (this._slOverlay) {
            this._slOverlay.remove();
            this._slOverlay = null;
        }
        if (this._bepOverlay) {
            this._bepOverlay.remove();
            this._bepOverlay = null;
        }
        // ★ 진행도 바 제거
        this._entryData = null;
        if (this._progressCanvas) {
            this._progressCanvas.remove();
            this._progressCanvas = null;
        }
    },

    // ========== 진입가 커스텀 오버레이 위치 업데이트 ==========
    updateEntryOverlay() {
        if (!this.areaSeries) return;
        // ◉ BUY/SELL
        if (this._entryOverlay && this._entryOverlayPrice) {
            const y = this.areaSeries.priceToCoordinate(this._entryOverlayPrice);
            if (y !== null && y > 0) {
                this._entryOverlay.style.top = y + 'px';
                this._entryOverlay.style.display = 'block';
            } else {
                this._entryOverlay.style.display = 'none';
            }
        }
        // Win
        if (this._tpOverlay && this._tpOverlayPrice) {
            const ty = this.areaSeries.priceToCoordinate(this._tpOverlayPrice);
            if (ty !== null && ty > 0) {
                this._tpOverlay.style.top = ty + 'px';
                this._tpOverlay.style.display = 'block';
            } else {
                this._tpOverlay.style.display = 'none';
            }
        }
        // Lose
        if (this._slOverlay && this._slOverlayPrice) {
            const sy = this.areaSeries.priceToCoordinate(this._slOverlayPrice);
            if (sy !== null && sy > 0) {
                this._slOverlay.style.top = sy + 'px';
                this._slOverlay.style.display = 'block';
            } else {
                this._slOverlay.style.display = 'none';
            }
        }
        // BEP
        if (this._bepOverlay && this._bepOverlayPrice) {
            const by = this.areaSeries.priceToCoordinate(this._bepOverlayPrice);
            if (by !== null && by > 0) {
                this._bepOverlay.style.top = by + 'px';
                this._bepOverlay.style.display = 'block';
            } else {
                this._bepOverlay.style.display = 'none';
            }
        }
    },

    // ========== SL/TP 진행도 바 ==========
    initProgressCanvas() {
        if (this._progressCanvas) this._progressCanvas.remove();
        const wrap = document.getElementById('qeChartWrap');
        if (!wrap) return;
        const canvas = document.createElement('canvas');
        canvas.id = 'qeProgressCanvas';
        canvas.style.cssText = 'position:absolute;top:0;right:0;width:100%;height:100%;pointer-events:none;z-index:5;';
        wrap.appendChild(canvas);
        this._progressCanvas = canvas;
    },

    drawProgressBars() {
        const canvas = this._progressCanvas;
        const ed = this._entryData;
        if (!canvas || !ed || !this.areaSeries || !this.chart) return;

        const rect = canvas.parentElement.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Y축 경계 = 차트 플롯 영역 끝
        let plotW = 0;
        try { plotW = this.chart.timeScale().width(); } catch(e) {}
        if (!plotW || plotW <= 0) plotW = canvas.width - 100;
        const barX = plotW - 2;
        const barWidth = 4;

        // ★ BEP 기준으로 막대 그리기 (진입가가 아닌 손익분기점)
        const bepPrice = ed.bep || ed.price;
        const bepY = this.areaSeries.priceToCoordinate(bepPrice);
        const tpY = this.areaSeries.priceToCoordinate(ed.tp);
        const slY = this.areaSeries.priceToCoordinate(ed.sl);
        if (bepY === null || tpY === null || slY === null) return;

        // ★ TP 막대 (초록): BEP → TP — 2단계 그라디언트
        // 1단계(BEP~중간): 0% → 30%  |  2단계(중간~TP): 50% → 100%
        const tpTop = Math.min(bepY, tpY);
        const tpBottom = Math.max(bepY, tpY);
        const tpHeight = tpBottom - tpTop;
        if (tpHeight > 0) {
            const tpGrad = ctx.createLinearGradient(0, bepY, 0, tpY);
            tpGrad.addColorStop(0, 'rgba(50, 255, 160, 0)');
            tpGrad.addColorStop(0.3, 'rgba(50, 255, 160, 0.15)');
            tpGrad.addColorStop(0.5, 'rgba(50, 255, 160, 0.30)');
            tpGrad.addColorStop(0.7, 'rgba(50, 255, 160, 0.55)');
            tpGrad.addColorStop(1, 'rgba(50, 255, 160, 1.0)');
            ctx.fillStyle = tpGrad;
            ctx.fillRect(barX, tpTop, barWidth, tpHeight);
        }

        // ★ SL 막대 (빨강): BEP → SL — 2단계 그라디언트
        // 1단계(BEP~중간): 0% → 30%  |  2단계(중간~SL): 50% → 100%
        const slTop = Math.min(bepY, slY);
        const slBottom = Math.max(bepY, slY);
        const slHeight = slBottom - slTop;
        if (slHeight > 0) {
            const slGrad = ctx.createLinearGradient(0, bepY, 0, slY);
            slGrad.addColorStop(0, 'rgba(255, 110, 120, 0)');
            slGrad.addColorStop(0.3, 'rgba(255, 110, 120, 0.15)');
            slGrad.addColorStop(0.5, 'rgba(255, 110, 120, 0.30)');
            slGrad.addColorStop(0.7, 'rgba(255, 110, 120, 0.55)');
            slGrad.addColorStop(1, 'rgba(255, 110, 120, 1.0)');
            ctx.fillStyle = slGrad;
            ctx.fillRect(barX, slTop, barWidth, slHeight);
        }
    },

    // ========== 진입 시 Y축만 조정 (X축 유지) ==========
    zoomToShowTPSL(entryPrice, tpPrice, slPrice) {
        if (!this.chart || !entryPrice) return;

        // Y축만 조정 — X축은 절대 건드리지 않음!
        const prices = [entryPrice];
        if (tpPrice && tpPrice > 0) prices.push(tpPrice);
        if (slPrice && slPrice > 0) prices.push(slPrice);

        // 현재 표시 중인 최근 틱 데이터 가격도 포함 (차트가 납작해지지 않도록)
        if (this.tickData && this.tickData.length > 0) {
            const recentTicks = this.tickData.slice(-20);
            recentTicks.forEach(t => {
                if (t.value) prices.push(t.value);
            });
        }

        const minPrice = Math.min(...prices);
        const maxPrice = Math.max(...prices);
        const padding = (maxPrice - minPrice) * 0.15;

        this._customPriceRange = {
            minValue: minPrice - padding,
            maxValue: maxPrice + padding
        };

        // autoscaleInfoProvider가 _customPriceRange를 사용하도록 강제 리렌더
        if (this.areaSeries) {
            this.areaSeries.applyOptions({});
        }

        // X축은 현재 뷰 그대로 유지! fitContent, setVisibleLogicalRange 호출 금지!
    },

    // ========== 차트 초기 상태 완벽 복원 (부드러운 트랜지션) ==========
    resetChartView() {
        if (!this.chart || !this.areaSeries) return;
        if (!this.tickData || this.tickData.length === 0) return;
        if (this._zoomAnimating) return; // ★ 애니메이션 중 뷰 변경 방지

        // 1. 커스텀 가격 범위 해제 → provider가 baseImpl() 호출 → 현재가 중심 autoScale
        this._customPriceRange = null;

        // 2. 가격축 자동스케일 + 마진 복원
        this.chart.priceScale('right').applyOptions({
            autoScale: true,
            scaleMargins: { top: 0.1, bottom: 0.1 }
        });

        // 3. 부드러운 미니 트랜지션 (300ms, 10스텝)
        const snapshotTotal = this._totalSeriesCount || this.tickData.length; // ★ 시리즈 실제 카운트 사용
        const targetVisibleBars = Math.max(15, Math.min(50, snapshotTotal));
        const rightOffset = 8;

        // 현재 보이는 범위 가져오기
        let currentVisibleBars = targetVisibleBars;
        try {
            const visibleRange = this.chart.timeScale().getVisibleLogicalRange();
            if (visibleRange) {
                currentVisibleBars = Math.round(visibleRange.to - visibleRange.from);
            }
        } catch(e) {}

        // 이미 목표와 비슷하면 즉시 설정
        if (Math.abs(currentVisibleBars - targetVisibleBars) < 3) {
            try {
                this.chart.timeScale().setVisibleLogicalRange({
                    from: snapshotTotal - targetVisibleBars,
                    to: snapshotTotal + rightOffset
                });
                this.chart.timeScale().scrollToPosition(8, false);
            } catch(e) {}
            return;
        }

        // ★ 미니 트랜지션 애니메이션
        this._zoomAnimating = true;
        const startBars = currentVisibleBars;
        const duration = 300;
        const steps = 10;
        const stepTime = duration / steps;
        let currentStep = 0;

        const easeOut = (t) => 1 - Math.pow(1 - t, 3);

        const animateReset = () => {
            if (!this._zoomAnimating) return;
            currentStep++;
            const progress = easeOut(currentStep / steps);
            const nowBars = Math.round(
                startBars + (targetVisibleBars - startBars) * progress
            );

            try {
                this.chart.timeScale().setVisibleLogicalRange({
                    from: snapshotTotal - nowBars,
                    to: snapshotTotal + rightOffset
                });
            } catch(e) {}

            if (currentStep < steps) {
                setTimeout(animateReset, stepTime);
            } else {
                this._zoomAnimating = false;
            }
        };

        animateReset();
    },

    // ========== 종목 변경 시 리셋 ==========
    reset() {
        this.tickData = [];
        this.lastPrice = 0;
        this.openPrice = 0;
        this.dailyOpen = 0;
        this.prevPrice = 0;
        this.targetPrice = 0;
        this.removeEntryLine();

        if (this.areaSeries) {
            // 시리즈 데이터 클리어
            this.areaSeries.setData([]);

            // 소수점 업데이트
            this.areaSeries.applyOptions({
                priceFormat: {
                    type: 'price',
                    precision: this.getDecimals(),
                    minMove: Math.pow(10, -this.getDecimals())
                }
            });
        }

        // 호가 초기화
        const priceEl = document.getElementById('qeQuotePrice');
        const changeEl = document.getElementById('qeChangeValue');
        const pctEl = document.getElementById('qeChangePct');
        if (priceEl) priceEl.textContent = '0.00';
        if (changeEl) { changeEl.textContent = '+0.00'; changeEl.className = 'qe-change-value'; }
        if (pctEl) { pctEl.textContent = '(0.00%)'; pctEl.className = 'qe-change-pct'; }

        console.log('[QeTickChart] 리셋 완료');

        // ★ 새 종목 히스토리 + D1 시가 로딩
        if (this.initialized) {
            this.loadInitialHistory();
        }
    },

    // ========== 리사이즈 ==========
    resize() {
        const container = document.getElementById('qeChartContainer');
        const wrap = document.getElementById('qeChartWrap');
        if (!this.chart || !container || !wrap) return;

        // wrap의 실제 렌더링 높이 사용 (CSS flex가 계산한 값)
        const w = wrap.clientWidth;
        const h = wrap.clientHeight;

        if (w > 0 && h > 0) {
            this.chart.applyOptions({ width: w, height: h });
        }
    },

    destroy() {
        if (this._resizeObserver) {
            this._resizeObserver.disconnect();
        }
        if (this.chart) {
            this.chart.remove();
            this.chart = null;
        }
        this.areaSeries = null;
        this.initialized = false;
    }
};
