/* ========================================
   Trading-X Account Tab
   Account Info 업데이트 + 거래내역 로드
   ======================================== */

// ========== 거래내역 로드 (Account 탭 전용 - 간단 버전) ==========
// ★ trading.js의 loadHistory()가 메인 함수 (period 지원, 중복 방지 등)
// ★ 이 함수는 Account 탭 초기화 시에만 사용
async function loadAccountHistory() {
    const container = document.getElementById('historyList');
    if (!container) return;
    
    container.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--text-muted);">Loading...</div>';
    
    console.log('[loadHistory] isDemo:', isDemo, 'token:', token ? 'exists' : 'none');
    
    try {
        // Demo/Live 모드에 따라 다른 API 호출
        const endpoint = isDemo ? '/demo/history' : '/mt5/history';
        console.log('[loadHistory] Fetching from:', endpoint);
        
        const response = await fetch(`${API_URL}${endpoint}`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        console.log('[loadHistory] Response:', data);
        
        if (data.history && data.history.length > 0) {
            let html = '';
            data.history.forEach(item => {
                const profit = item.profit || 0;
                const profitClass = profit >= 0 ? 'profit-positive' : 'profit-negative';
                const profitSign = profit >= 0 ? '+' : '';
                // ★★★ 포지션 타입 정규화 (POSITION_TYPE_BUY → BUY) ★★★
                const itemType = String(item.type || '').toUpperCase();
                const isBuy = itemType === 'BUY' || itemType.includes('BUY') || item.type === 0;
                const typeClass = isBuy ? 'type-buy' : 'type-sell';
                const typeText = isBuy ? 'BUY' : 'SELL';
                
                // Live 모드에서는 entry/exit 대신 price만 있을 수 있음
                const entryPrice = item.entry || item.price || 0;
                const exitPrice = item.exit || item.price || 0;
                
                html += `
                    <div class="history-item">
                        <span class="history-left">${item.symbol || '-'} <span class="${typeClass === 'type-buy' ? 'buy' : 'sell'}">${typeText}</span> <span class="lot">${item.volume || 0}lot</span></span>
                        <span class="history-center">${item.time || '-'}</span>
                        <span class="history-right ${profitClass}">${profitSign}$${profit.toFixed(2)}</span>
                    </div>
                `;
            });
            container.innerHTML = html;
            
            // Account Info 업데이트
            updateAccountInfoFromHistory(data.history);
        } else {
            container.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--text-muted);">거래 내역이 없습니다</div>';
            resetAccountInfo();
        }
    } catch (error) {
        console.error('[loadHistory] Error:', error);
        container.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--text-muted);">거래 내역을 불러올 수 없습니다</div>';
        resetAccountInfo();
    }
    
    // 히스토리 로드 완료 후 패널 동기화
    if (typeof syncAccountInfoToPanels === 'function') {
        syncAccountInfoToPanels();
    }
}

// Account Info 업데이트 함수 (오늘 기준)
function updateAccountInfoFromHistory(historyData) {
    if (!historyData || historyData.length === 0) {
        resetAccountInfo();
        return;
    }
    
    // 오늘 날짜 (MM/DD 형식)
    const today = new Date();
    const todayStr = `${String(today.getMonth() + 1).padStart(2, '0')}/${String(today.getDate()).padStart(2, '0')}`;
    
    // 오늘 거래만 필터링
    let todayTrades = historyData.filter(item => item.time && item.time.startsWith(todayStr));
    
    // 전체 통계도 계산 (오늘 거래가 없을 경우 대비)
    let allWins = 0;
    let allLosses = 0;
    let allPL = 0;
    
    historyData.forEach(item => {
        const profit = item.profit || 0;
        allPL += profit;
        if (profit >= 0) {
            allWins++;
        } else {
            allLosses++;
        }
    });
    
    // 오늘 통계 계산
    let todayWins = 0;
    let todayLosses = 0;
    let todayPL = 0;
    
    todayTrades.forEach(item => {
        const profit = item.profit || 0;
        todayPL += profit;
        if (profit >= 0) {
            todayWins++;
        } else {
            todayLosses++;
        }
    });
    
    // Account Info UI 업데이트
    const winLoseEl = document.getElementById('accWinLose');
    const todayPLEl = document.getElementById('accTodayPL');
    const currentPLEl = document.getElementById('accCurrentPL');
    
    // ★ 항상 오늘 기준 Win/Lose (기간 필터 무관)
    const displayWins = todayWins;
    const displayLosses = todayLosses;
    // ★★★ Today P/L은 항상 _todayPLFixed 사용 ★★★
    const displayPL = window._todayPLFixed || 0;
    
    if (winLoseEl) {
        winLoseEl.textContent = `${displayWins} / ${displayLosses}`;
    }
    
    if (todayPLEl) {
        if (displayPL > 0) {
            todayPLEl.textContent = '+$' + displayPL.toFixed(2);
            todayPLEl.style.color = 'var(--text-primary)';
        } else if (displayPL < 0) {
            todayPLEl.textContent = '-$' + Math.abs(displayPL).toFixed(2);
            todayPLEl.style.color = 'var(--sell-color)';
        } else {
            todayPLEl.textContent = '$0.00';
            todayPLEl.style.color = 'var(--text-primary)';
        }
    }
    
    if (currentPLEl) {
        currentPLEl.textContent = '$0.00';
        currentPLEl.style.color = 'var(--text-primary)';
    }
    
    console.log('[updateAccountInfoFromHistory] Today trades:', todayTrades.length, 'Total trades:', historyData.length);
}

// Account Info 초기화
function resetAccountInfo() {
    const winLoseEl = document.getElementById('accWinLose');
    const todayPLEl = document.getElementById('accTodayPL');
    const currentPLEl = document.getElementById('accCurrentPL');
    
    if (winLoseEl) winLoseEl.textContent = '0 / 0';
    if (todayPLEl) {
        todayPLEl.textContent = '$0.00';
        todayPLEl.style.color = 'var(--text-primary)';
    }
    if (currentPLEl) {
        currentPLEl.textContent = '$0.00';
        currentPLEl.style.color = 'var(--text-primary)';
    }
}

// Account 탭 전환 시 자동 로드
function initAccountTab() {
    loadHistory();
}
