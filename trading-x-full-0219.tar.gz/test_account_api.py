#!/usr/bin/env python3
"""
Account 탭 API 테스트 스크립트
"""

import asyncio
import httpx
import json

BASE_URL = "http://localhost:8000/api"

async def test_account_apis():
    print("=" * 60)
    print("Account 탭 API 테스트")
    print("=" * 60)

    async with httpx.AsyncClient(timeout=30.0) as client:
        # 1. 로그인하여 토큰 획득
        print("\n[1] 로그인 (테스트 계정)...")
        try:
            login_resp = await client.post(
                f"{BASE_URL}/auth/login",
                json={"email": "test_api@test.com", "password": "test123"}
            )
            if login_resp.status_code == 200:
                token_data = login_resp.json()
                token = token_data.get("access_token")
                print(f"    토큰 획득: {token[:20]}...")
            else:
                print(f"    로그인 실패: {login_resp.status_code}")
                print(f"    응답: {login_resp.text}")
                return
        except Exception as e:
            print(f"    로그인 오류: {e}")
            return

        headers = {"Authorization": f"Bearer {token}"}

        # 2. GET /account-info 테스트
        print("\n[2] GET /account-info...")
        try:
            resp = await client.get(f"{BASE_URL}/mt5/account-info", headers=headers)
            data = resp.json()
            print(f"    상태: {resp.status_code}")
            print(f"    broker: {data.get('broker')}")
            print(f"    account: {data.get('account')}")
            print(f"    balance: {data.get('balance')}")
            print(f"    equity: {data.get('equity')}")
            print(f"    margin: {data.get('margin')}")
            print(f"    free_margin: {data.get('free_margin')}")
            print(f"    positions_count: {data.get('positions_count')}")
            print(f"    has_mt5: {data.get('has_mt5')}")
        except Exception as e:
            print(f"    오류: {e}")

        # 3. GET /positions 테스트
        print("\n[3] GET /positions...")
        try:
            resp = await client.get(f"{BASE_URL}/mt5/positions", headers=headers)
            data = resp.json()
            print(f"    상태: {resp.status_code}")
            print(f"    success: {data.get('success')}")
            print(f"    count: {data.get('count')}")
            print(f"    source: {data.get('source', 'N/A')}")
            if data.get('positions'):
                for pos in data['positions'][:3]:
                    print(f"    - {pos.get('symbol')} {pos.get('type')} {pos.get('volume')} lot, P/L: {pos.get('profit')}")
        except Exception as e:
            print(f"    오류: {e}")

        # 4. GET /history 테스트
        print("\n[4] GET /history...")
        try:
            resp = await client.get(f"{BASE_URL}/mt5/history", headers=headers)
            data = resp.json()
            print(f"    상태: {resp.status_code}")
            print(f"    source: {data.get('source', 'N/A')}")
            history = data.get('history', [])
            print(f"    거래 수: {len(history)}")
            if history:
                for h in history[:5]:
                    print(f"    - {h.get('time')} {h.get('symbol')} {h.get('type')} P/L: {h.get('profit')}")
        except Exception as e:
            print(f"    오류: {e}")

    print("\n" + "=" * 60)
    print("테스트 완료")
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(test_account_apis())
