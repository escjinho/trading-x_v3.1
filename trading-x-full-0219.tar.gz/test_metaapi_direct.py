#!/usr/bin/env python3
"""
MetaAPI 캐시 직접 테스트
"""

import sys
sys.path.insert(0, '/var/www/trading-x/backend')

from app.api.metaapi_service import (
    get_metaapi_account,
    get_metaapi_positions,
    is_metaapi_connected
)

print("=" * 60)
print("MetaAPI 캐시 직접 테스트")
print("=" * 60)

print(f"\n[1] 연결 상태: {is_metaapi_connected()}")

print("\n[2] 계정 정보:")
account = get_metaapi_account()
if account:
    print(f"    balance: {account.get('balance')}")
    print(f"    equity: {account.get('equity')}")
    print(f"    margin: {account.get('margin')}")
    print(f"    freeMargin: {account.get('freeMargin')}")
    print(f"    leverage: {account.get('leverage')}")
else:
    print("    계정 정보 없음")

print("\n[3] 포지션:")
positions = get_metaapi_positions()
if positions:
    print(f"    포지션 수: {len(positions)}")
    for pos in positions[:5]:
        print(f"    - {pos.get('symbol')} {pos.get('type')} {pos.get('volume')} lot")
else:
    print("    포지션 없음 (또는 빈 리스트)")

print("\n" + "=" * 60)
