#!/usr/bin/env python3
"""
SL/TP 주문 테스트 v2 - 포지션 상세 확인
"""

import asyncio
import httpx
import json

BASE_URL = "http://localhost:8000/api"

async def test():
    print("=" * 60)
    print("SL/TP 주문 테스트 v2")
    print("=" * 60)

    async with httpx.AsyncClient(timeout=30.0) as client:
        # 로그인
        login_resp = await client.post(
            f"{BASE_URL}/auth/login",
            json={"email": "test_api@test.com", "password": "test123"}
        )
        token = login_resp.json().get("access_token")
        headers = {"Authorization": f"Bearer {token}"}
        print("✅ 로그인 성공")

        # BUY 주문 (target=50)
        print("\n[1] BTCUSD BUY 주문 (target=$50)...")
        order_resp = await client.post(
            f"{BASE_URL}/mt5/order",
            params={
                "symbol": "BTCUSD",
                "order_type": "BUY",
                "volume": 0.01,
                "target": 50,
                "magic": 100001
            },
            headers=headers
        )
        order_data = order_resp.json()
        print(f"    결과: {order_data}")

        if not order_data.get("success"):
            print("    ❌ 주문 실패")
            return

        position_id = order_data.get("positionId")
        print(f"    positionId: {position_id}")

        # 5초 대기 후 포지션 확인
        print("\n[2] 5초 대기 후 포지션 확인...")
        await asyncio.sleep(5)

        pos_resp = await client.get(f"{BASE_URL}/mt5/positions", headers=headers)
        pos_data = pos_resp.json()
        print(f"    포지션 수: {pos_data.get('count', 0)}")
        print(f"    source: {pos_data.get('source')}")

        for pos in pos_data.get('positions', []):
            print(f"\n    ▶ 포지션 전체 데이터:")
            print(json.dumps(pos, indent=6, default=str))

        # 청산
        print("\n[3] 청산...")
        close_resp = await client.post(
            f"{BASE_URL}/mt5/close",
            params={"symbol": "BTCUSD", "magic": 100001, "position_id": position_id},
            headers=headers
        )
        print(f"    청산 결과: {close_resp.json()}")

    print("\n" + "=" * 60)

if __name__ == "__main__":
    asyncio.run(test())
